/** 清洁类游戏 */
class ClearUp extends MC{
    //---------------------------------------------------------编辑器的属性接口及方法接口定义----------------------------------------------------
    private ATTRIBUTES_PAGE = [
        "ATTRIBUTES_PAGE_START",
        "title---['3加4等于多少？','5加2等于多少？']---此游戏题的题目。",
		"options---[[7,5,6],[6,7,5]]---此游戏题的选项。",
		"answer---[[1,2]]---此游戏题的答案。",
        "ATTRIBUTES_PAGE_END"
    ];
    private METHOD_PAGE = [
        "METHOD_PAGE_START",
        "init---null---设置界面是否可操作。",
        "submitAnswer---默认---提交答案。默认表示提交页面属性中配置的答案，也可以填写其它答案。",
		"steep---1---执行指定的步骤。",
        "next---null---下一步。",
        "METHOD_PAGE_END"
    ];

    private LIST_INST = [
        "LIST_INST_START",
        "ClearUp_Welcome",
        "ClearUp_Main",
        "LIST_INST_END"
    ];
    private ATTRIBUTES_ClearUp_Welcome = [
        "ATTRIBUTES_ClearUp_Welcome_START",
        "index---1---此拖动对象的缩影。",
        "data---[2,5]---携带的参数。",
        "hits---['hit1','hit2']---此拖动对象需要碰撞的对象，可以有多个。",
        "bindObj---[]---绑定对象，可以有多个。以拖动对象关联的对象，当拖动对象的状态改变时，可以相应的改变绑定对象的状态。",
        "dragSound---1---开始拖动此实例时播放指定次数声音，拖动放开时立刻停止播放。",
        "fixedSound---1---拖动的实例被固定时播放指定次数的声音。",
        "ATTRIBUTES_ClearUp_Welcome_END"
    ];
    private METHOD_ClearUp_Welcome = [
        "METHOD_ClearUp_Welcome_START",
        "correct---null---纠错。",
        "METHOD_ClearUp_Welcome_END"
    ];

    private ATTRIBUTES_ClearUp_Main = [
        "ATTRIBUTES_ClearUp_Main_START",
        "index---1---此碰撞对象的缩影。",
        "data---[2,5]---携带的参数。",
        "ATTRIBUTES_ClearUp_Main_END"
    ];
	private METHOD_ClearUp_Main = [
        "METHOD_ClearUp_Main_START",
        "steep---1---执行指定的步骤。",
        "next---null---下一步。",
        "METHOD_ClearUp_Main_END"
    ];
    //-------------------------------------------------------------------------------------------------------------------------------------------

    constructor(){ super(); }

    private nextTime:number;
    private steepIndex:number;
    private index:number;
    private curArr:Array<number>;
    private arr0:Array<number>;
    private arr1:Array<number>;
    private arr2:Array<number>;
    private arr3:Array<number>;
    private arr4:Array<number>;
    private arr5:Array<number>;
    private arr6:Array<number>;
    private arr7:Array<number>;
    private arr8:Array<number>;
    private arr9:Array<number>;
    private arr10:Array<number>;
    private arr11:Array<number>;
    private arr12:Array<number>;
    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
        this.nextTime = 0;
        this.index = 0;
        this.steepIndex = 0;
        this.arr0 = [2, 5, 13];
        this.arr1 = [2, 6];
        this.arr2 = [1.5, 5];
        this.arr3 = [2];
        this.arr4 = [2];
        this.arr5 = [2];
        this.arr6 = [3];
        this.arr7 = [3];
        this.arr8 = [3];
        this.arr9 = [3];
        this.arr10 = [3];
        this.arr11 = [3];
        this.arr12 = [3];
		super.construct();
	}

    /** 此方法不一定在初始化方法中调用，也可能是在界面中调用。 */
    public init():void{
        //this.setInterval(this.arr0);
        setParentMsgBackcall(this.handleSteep, this);
    }

    /** 自动执行， 设置一组时间，以便定时执行相应的步骤。
     * arr 要执行的时间数组。
     * skipSteep 是否增加步骤，让当前步骤跳过指定的数。 */
    public setInterval(arr, skipSteep=0):void{
        this.curArr = arr;
        this.index = 0;
        this.nextTime = arr[0];
        this.steepIndex += skipSteep;
        setTimeout(()=>{this.setIntervalHandler()}, this.nextTime*1000);
    }
    private setIntervalHandler():void{
        //trace(this.steepIndex);
        if(this.steepIndex < 2){
            this["welcome"]["steep"+this.steepIndex]();
        }else{
            this["main"]["steep"+this.steepIndex]();
        }
        this.index++;
        this.steepIndex++;
        if(this.index == this.curArr.length) return;
        this.nextTime = this.curArr[this.index]-this.curArr[this.index-1]; 
        setTimeout(()=>{this.setIntervalHandler()}, this.nextTime*1000);
    }

    /** 由app中调用执行相应的方法，时间点事件的回调方法。
     * param app中传来的需要执行的方法与参数。 */
    public handleSteep(str:string=""):void{
        var arr = str.split("||");
        var f:string = arr[0];
        var p:string = arr.length > 1 ? arr[1] : null;
        var view = (f=="steep0" || f=="steep1") ? "welcome" : "main";
        p ?  this[""+view][""+f](p) : this[""+view][""+f]();
    }

    /** 由app调用，执行页面卸载前的清理 */
    public destroy():void{
        clearParentBackcall();
        if(this["welcome"]["destroy"]) this["welcome"]["destroy"]();
        if(this["main"]["destroy"]) this["main"]["destroy"]();
    }
}

/** -----------------------------------定义此控制器用到的实例类，及其公有属性与方法----------------------------- */
class ClearUp_Welcome extends MC{
    constructor(){ super(); }

    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
	}

    public destroy():void{
    }

    public init():void{
    }

    /** 显示标题 */
    public steep0():void{
        this["title"].play();
    }

    /** 隐藏Welcome页，显示主界面 */
    public steep1():void{
        this.visible = false;
    }
}

class ClearUp_Main extends MC{
    constructor(){ super(); }
    private pressX:number;
    private pressY:number;
    private curIndex:number;
    private caoTotal:number;
    private bianTotal:number;
    private zzwTotal:number;
    private wsTotal:number;
    private huiTotal:number;
    private qtTotal:number;
    private qbTotal:number;
    private caoliaoTotal:number;
    private sltTotal:number;
    private spTotal:number;
    private fruitTotal:number;

    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
        this.curIndex = 0;
        this.caoTotal = 0;
        this.bianTotal = 0;
        this.zzwTotal = 0;
        this.wsTotal = 0;
        this.huiTotal = 0;
        this.qtTotal = 0;
        this.qbTotal = 0;
        this.caoliaoTotal = 0;
        this.sltTotal = 0;
        this.spTotal = 0;
        this.fruitTotal = 0;
	}

    public destroy():void{
    }

    public init():void{
        this["maClick"].visible = false;
        this["chanBian"].visible = false;
        this["shaZzw"].visible = false;
        this["tbWs"].visible = false;
        this["saoba"].visible = false;
        this["tipQt"].visible = false;
        this["shaQt"].visible = false;
        this["shaQb"].visible = false;
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,8)=="caoliao_") item.visible = false;
            if(item.name && item.name.substr(0,11)=="caoliaoHit_") item.visible = false;
            if(item.name && item.name.substr(0,4)=="slt_") item.visible = false;
            if(item.name && item.name.substr(0,7)=="sltHit_") item.visible = false;
            if(item.name && item.name.substr(0,3)=="sp_") item.visible = false;
            if(item.name && item.name.substr(0,6)=="spHit_") item.visible = false;
            if(item.name && item.name.substr(0,5)=="fruit") item.visible = false;
        }
    }

    /** 设置小马的点击侦听 */
    public steep2():void{
        setAnswerScore(3);
        this.on(EventType.CLICK, this.maClickHandler, this);
    }
    /** 点击小马后，小马出圈 */
    private maClickHandler(e:createjs.MouseEvent):void{
        if(hitTest(this["ma"], e.localX, e.localY) == true){
            //清出点击操作
            this.removeAllEventListeners(EventType.CLICK);
            //做答正确
            this.showSpeakTip(6);
            this["ma"].gotoAndPlay("walk");
            //根据得分情况来播放对应的视频。
            VideoHelper.playRight();
            //立刻隐藏点击提示
            this["maClick"].visible = false;
        }else{
            //做答错误
            //VideoHelper.playWrong();
            VideoHelper.playWrongArr([1, 2]);
        }
    }

    /** 点击小马提示, 在APP的时间点事件中回调 */
    private clickMaTip():void{
        this["maClick"].visible = true;
        this["maClick"]["finger"].gotoAndPlay(1);
        //提前开启界面操作，每一个(除了tip分支节点的视频外)视频播放前，都会屏蔽界面操作。
        touchRootEnabled(true);
    }
    
    /** ------------------------------------------清理杂草---------------------------------------------------- */
    /** 调出垃圾筒 */
    public steep3():void{
        this["garbage"].play();
    }
    /** 让草跳动，并设置可点击 */
    public steep4():void{
        setAnswerScore(5);
        var item;
        this.on(EventType.CLICK, ()=>{
            var n = Math.ceil(Math.random()*2);
            VideoHelper.playTip(n);
        }, this);
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,4)=="cao_"){
                item.play();
                this.addDrag(item, this.caoEndHandler, null, null, this.caoDownHandler);
                this.caoTotal++;
            }
        }
    }
    
    private caoDownHandler(e):void{
        this.pressX = e.currentTarget.x;
        this.pressY = e.currentTarget.y;
    }
    private caoEndHandler(e):void{
        var item:createjs.MovieClip = e.currentTarget;
        var garbage:createjs.MovieClip = this["garbage"];
        var hit:createjs.MovieClip = garbage["hitObj"];
        if(hitTestObj(garbage, item) == true){
            item.x = hit.x;
            item.y = hit.y;
            item.gotoAndPlay("hide");
            garbage.addChild(item);
            this.curIndex++;
            if(this.curIndex == this.caoTotal-2){
                VideoHelper.playTip(5);
            }else{
                VideoHelper.playTip(this.curIndex+2);
            }
            if(this.curIndex == this.caoTotal){
                this.curIndex = 0;
                VideoHelper.playRight();
            }
        }else{
            item.x = this.pressX;
            item.y = this.pressY;
            VideoHelper.playWrong();
        }
    }

    /** 全部草都拖完了 */
    public steep5():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,4)=="cao_") this.delDrag(item);
        }
        this.showSpeakTip(7);
        this["garbage"].play();
    }

    /** ------------------------------------------清理粪便---------------------------------------------------- */
    public steep6():void{
        this.showTool(1, this.steep7);
    }
    public steep7():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,4)=="bian"){
                this.bianTotal++;
            }
        }
        this["garbage"].gotoAndPlay(1);
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
        this["chanBian"].visible = true;
        this.addDrag(this["chanBian"], this.bianChanEnd, this.bianChanMove);
    }
    
    private bianChanMove(e):void{
        var drag = e.currentTarget;
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(drag["haveBian"] != true && item.name && item.name.substr(0,4)=="bian" && hitTestObj(drag, item)){
                item.x = drag.hitObj.x;
                item.y = drag.hitObj.y;
                drag.addChild(item);
                drag.item = item;
                drag["haveBian"] = true;
            }
        }
    }
    private bianChanEnd(e):void{
        var drag:createjs.MovieClip = e.currentTarget;
        var garbage:createjs.MovieClip = this["garbage"];
        var hit:createjs.MovieClip = garbage["hitObj"];
        var item = drag["item"];
        if(hitTestObj(garbage, drag) == true){
            drag["haveBian"] = false;
            item.x = hit.x;
            item.y = hit.y;
            item.gotoAndPlay("hide");
            garbage.addChild(item);
            this.curIndex++;
            if(this.curIndex == this.bianTotal){
                this.curIndex = 0;
                drag.visible = false;
                this.showSpeakTip(3);
                this.parent["setInterval"](this.parent["arr3"], 1);
            }
        }else{
            this.judgeBound(e.currentTarget);
        }
    }

    /** ------------------------------------------清理蜘蛛网---------------------------------------------------- */
    public steep8():void{
        this["garbage"].play();
        this.showTool(2, this.steep9);
    }
    public steep9():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,3)=="zzw"){
                this.zzwTotal++;
            }
        }
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
        this["shaZzw"].visible = true;
        this.addDrag(this["shaZzw"], this.zzwEnd, this.zzwChanMove);
    }
    private zzwChanMove(e):void{
        var drag = e.currentTarget;
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item["finish"] != true && item.name && item.name.substr(0,3)=="zzw" && hitTestObj(drag, item)){
                item.gotoAndStop(item.currentFrame+1);
                if(item.currentFrame == item.totalFrames-1){
                    item["finish"] = true;
                    this.curIndex++;
                    if(this.curIndex == this.zzwTotal){
                        this.curIndex = 0;
                        drag.visible = false;
                        this.showSpeakTip(1);
                        this.parent["setInterval"](this.parent["arr4"], 1);
                    }
                }
            }
        }
    }
    private zzwEnd(e):void{
        this.judgeBound(e.currentTarget);
    }

    /** ------------------------------------------清理污水---------------------------------------------------- */
    public steep10():void{
        this.showTool(3, this.steep11);
    }
    public steep11():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,2)=="ws"){
                this.wsTotal++;
            }
        }
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
        this["tbWs"].visible = true;
        this.addDrag(this["tbWs"], this.wsEnd, this.wsChanMove);
    }
    private wsChanMove(e):void{
        var drag = e.currentTarget;
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item["finish"] != true && item.name && item.name.substr(0,2)=="ws" && hitTestObj(drag, item)){
                item.gotoAndStop(item.currentFrame+1);
                if(item.currentFrame == item.totalFrames-1){
                    item["finish"] = true;
                    this.curIndex++;
                    if(this.curIndex == this.wsTotal){
                        this.curIndex = 0;
                        drag.visible = false;
                        this.showSpeakTip(1);
                        this.parent["setInterval"](this.parent["arr5"], 1);
                    }
                }
            }
        }
    }
    private wsEnd(e):void{
        this.judgeBound(e.currentTarget);
    }

    /** ------------------------------------------清理地面---------------------------------------------------- */
    public steep12():void{
        this.showTool(4, this.steep13);
    }
    public steep13():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,3)=="hui"){
                this.huiTotal++;
            }
        }
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
        this["saoba"].visible = true;
        this.addDrag(this["saoba"], this.huiEnd, this.huiChanMove);
    }
    private huiChanMove(e):void{
        var drag = e.currentTarget;
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item["finish"] != true && item.name && item.name.substr(0,3)=="hui" && hitTestObj(drag, item)){
                item.gotoAndStop(item.currentFrame+1);
                if(item.currentFrame == item.totalFrames-1){
                    item["finish"] = true;
                    this.curIndex++;
                    if(this.curIndex == this.huiTotal){
                        this.curIndex = 0;
                        drag.visible = false;
                        this.showSpeakTip(4);
                        this.parent["setInterval"](this.parent["arr6"], 1);
                    }
                }
            }
        }
    }
    private huiEnd(e):void{
        this.judgeBound(e.currentTarget);
    }

    /** ------------------------------------------青苔提示---------------------------------------------------- */
    public steep14():void{
        this.showTool(5, this.steep15);
    }
    public steep15():void{
        this.hideTool();
        this["tipQt"].visible = true;
        this["tipQt"].on("end", this.qtTipHandler, this); 
    }

    private qtTipHandler(e):void{
        this.showTool(6, this.steep16);
    }

     public steep16():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,2)=="qt"){
                this.qtTotal++;
            }
        }
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
        this["shaQt"].visible = true;
        this.addDrag(this["shaQt"], this.qtEnd, this.qtChanMove);
    }
    private qtChanMove(e):void{
        var drag = e.currentTarget;
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item["finish"] != true && item.name && item.name.substr(0,2)=="qt" && hitTestObj(drag, item)){
                item.gotoAndStop(item.currentFrame+1);
                if(item.currentFrame == item.totalFrames-1){
                    item["finish"] = true;
                    this.curIndex++;
                    if(this.curIndex == this.qtTotal){
                        this.curIndex = 0;
                        drag.visible = false;
                        this.showSpeakTip(7);
                        this.parent["setInterval"](this.parent["arr7"], 2);
                    }
                }
            }
        }
    }
    private qtEnd(e):void{
        this.judgeBound(e.currentTarget);
    }

    /** ------------------------------------------清理墙壁上的灰尘---------------------------------------------------- */
    public steep17():void{
        this.showTool(7, this.steep18);
    }
    public steep18():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,2)=="qb"){
                this.qbTotal++;
            }
        }
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
        this["shaQb"].visible = true;
        this.addDrag(this["shaQb"], this.qbEnd, this.qbChanMove);
    }

    private qbChanMove(e):void{
        var drag = e.currentTarget;
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item["finish"] != true && item.name && item.name.substr(0,2)=="qb" && hitTestObj(drag, item)){
                item.gotoAndStop(item.currentFrame+1);
                if(item.currentFrame == item.totalFrames-1){
                    item["finish"] = true;
                    this.curIndex++;
                    if(this.curIndex == this.qbTotal){
                        this.curIndex = 0;
                        drag.visible = false;
                        this.showSpeakTip(4);
                        this.parent["setInterval"](this.parent["arr8"], 1);
                    }
                }
            }
        }
    }
    private qbEnd(e):void{
        this.judgeBound(e.currentTarget);
    }

    /** ------------------------------------------摆放草料---------------------------------------------------- */
    public steep19():void{
        this.showTool(8, this.steep20);
    }
    public steep20():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,8)=="caoliao_"){
                this.caoliaoTotal++;
                item.visible = true;
                this.addDrag(item, this.caoliaoDragEnd, null, null, this.caoliaoDownHandler);
            }
            if(item.name && item.name.substr(0,11)=="caoliaoHit_"){
                item.visible = true;
            }
        }
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
    }

    private caoliaoDownHandler(e):void{
        this.pressX = e.currentTarget.x;
        this.pressY = e.currentTarget.y;
    }
    private caoliaoDragEnd(e):void{
        var item:createjs.MovieClip = e.currentTarget;
        var n = item.name.split("_")[1];
        var hit:createjs.MovieClip = this["caoliaoHit_"+n];
        if(hitTestObj(hit, item) == true){
            item.x = hit.x;
            item.y = hit.y;
            this.curIndex++;
            this.delDrag(item);
            if(this.curIndex == this.caoliaoTotal){
                this.curIndex = 0;
                this.parent["setInterval"](this.parent["arr9"], 1);
            }
        }else{
            item.x = this.pressX;
            item.y = this.pressY;
        }
    }

    /** ------------------------------------------摆放水龙头---------------------------------------------------- */
    public steep21():void{
        this.showTool(9, this.steep22);
    }
    public steep22():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,4)=="slt_"){
                this.sltTotal++;
                item.visible = true;
                this.addDrag(item, this.sltDragEnd, null, null, this.sltDownHandler);
            }
            if(item.name && item.name.substr(0,7)=="sltHit_"){
                item.visible = true;
                item.gotoAndStop(1);
            }
        }
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
    }

    private sltDownHandler(e):void{
        this.pressX = e.currentTarget.x;
        this.pressY = e.currentTarget.y;
    }
    private sltDragEnd(e):void{
        var item:createjs.MovieClip = e.currentTarget;
        var n = item.name.split("_")[1];
        var hit:createjs.MovieClip = this["sltHit_"+n];
        if(hitTestObj(hit, item) == true){
            item.visible = false;
            hit.gotoAndStop(2);
            this.curIndex++;
            this.delDrag(item);
            if(this.curIndex == this.sltTotal){
                this.curIndex = 0;
                hit.gotoAndStop(3);
                hit.on(EventType.CLICK, this.sltOpenHandler, this, true);
                hit.on("end", this.sltEndHandler, this, true);
            }
        }else{
            item.x = this.pressX;
            item.y = this.pressY;
        }
    }
    private sltOpenHandler(e):void{
        e.currentTarget.play();
    }
    private sltEndHandler(e):void{
        e.currentTarget.on(EventType.CLICK, this.sltCloseHandler, this, true);
    }
    private sltCloseHandler(e):void{
        e.currentTarget.play();
        this.parent["setInterval"](this.parent["arr10"], 1);
    }

    /** ------------------------------------------摆放食盆---------------------------------------------------- */
    public steep23():void{
        this.showTool(10, this.steep24);
    }
    public steep24():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,3)=="sp_"){
                this.spTotal++;
                item.visible = true;
                this.addDrag(item, this.spDragEnd, null, null, this.spDownHandler);
            }
            if(item.name && item.name.substr(0,6)=="spHit_"){
                item.visible = true;
                item.gotoAndStop(1);
            }
        }
        this["toolPanel"].panel.tx.removeAllEventListeners("click");
        this.hideTool();
    }

    private spDownHandler(e):void{
        this.pressX = e.currentTarget.x;
        this.pressY = e.currentTarget.y;
    }
    private spDragEnd(e):void{
        var item:createjs.MovieClip = e.currentTarget;
        var n = item.name.split("_")[1];
        var hit:createjs.MovieClip = this["spHit_"+n];
        if(hitTestObj(hit, item) == true){
            item.visible = false;
            hit.gotoAndStop(2);
            this.curIndex++;
            this.delDrag(item);
            if(this.curIndex == this.sltTotal){
                this.curIndex = 0;
                this.parent["setInterval"](this.parent["arr11"], 1);
            }
        }else{
            item.x = this.pressX;
            item.y = this.pressY;
        }
    }

    /** ------------------------------------------摆放水果---------------------------------------------------- */
    public steep25():void{
        var item;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i);
            if(item.name && item.name.substr(0,5)=="fruit") item.visible = true;
            if(item.name && item.name.substr(0,10)=="fruit_drag") this.fruitTotal++;
            
        }
        
        if(item) setTimeout(()=>{
            item = this.getChildByName("fruit_drag_"+this.curIndex);
            this.addDrag(item, this.fruitDragEnd, null, null, this.fruitDownHandler);
            item.play();
        }, 2000);
    }

     private fruitDownHandler(e):void{
        this.pressX = e.currentTarget.x;
        this.pressY = e.currentTarget.y;
    }
    private fruitDragEnd(e):void{
        var drag:createjs.MovieClip = e.currentTarget;
        var arr = drag.name.split("_");
        var n = parseInt(arr[arr.length-1]);
        var hit:createjs.MovieClip = this["spHit_0"];
        if(n == this.curIndex && hitTestObj(hit, drag) == true){
            drag.visible = false;
            hit.play();
            this.curIndex++;
            this.delDrag(drag);
            if(this.curIndex == this.fruitTotal){
                this.curIndex = 0;
                this.parent["setInterval"](this.parent["arr12"], 1);
                for(var i:number=0; i<this.numChildren; i++){
                    drag = this.getChildAt(i) as createjs.MovieClip;
                    if(drag.name && drag.name.substr(0,5)=="fruit") drag.visible = false;
                }
            }else{
                setTimeout(()=>{
                var dd:any = this.getChildByName("fruit_drag_"+this.curIndex);
                this.addDrag(dd, this.fruitDragEnd, null, null, this.fruitDownHandler);
                dd.play();
            }, 2000);
            }
        }else{
            drag.x = this.pressX;
            drag.y = this.pressY;
        }
    }

    /** ------------------------------------------小马回家---------------------------------------------------- */
    public steep27():void{
        this.addChild(this["ma"]);
        this["ma"].gotoAndPlay("goHome");
    }


    /** 判断拖动对象的边界，如果超出边界，回到边界 */
    private judgeBound(drag:createjs.MovieClip):void{
        if(drag.x < 250) drag.x = 250;
        if(drag.x > 1000) drag.x = 1000;
        if(drag.y < 0) drag.y = 0;
        if(drag.y > 600) drag.y = 600;
    }

    
    

    /** 延时提示计时器的ID */
    private setTimeoutId:number;
    /** 设置延时回调，执行前可以通过clearTimeoutFun方法清除。不要同时设置多个，不然将无法在执行前清除。
     * backcall 要回调的函数。以这种方式定义：()=>{}。 
     * time 延时的时间。*/
    private setTimeoutFun(backcall:Function, time:number):void{
        this.setTimeoutId = setTimeout(backcall, time);
    }
    /** 清出setTimeoutFun设置的延时回调。 */
    private clearTimeoutFun():void{
        if(this.setTimeoutId != -1){
            clearTimeout(this.setTimeoutId);
            this.setTimeoutId = -1;
        }
    }

    /** 显示工具面板 type  从1开始*/
    public showTool(type:number, backCallFun):void{
        this["toolPanel"].panel.gotoAndStop(type-1);
        this["toolPanel"].panel.tx.on("click", backCallFun, this);
        this["toolPanel"].play();
    }
    /** 隐藏工具面板 */
    public hideTool():void{
        this["toolPanel"].play();
    }

    /** 显示操作提示 steep 要提示的步骤，从1开始 */
    public showOperTip(steep:number):void{
        this["operTip"].panel.gotoAndStop(steep-1);
        this["operTip"].play();
    }
    /** 隐藏操作提示 */
    public hideOperTip():void{
        this["operTip"].play();
    }

    /** 显示语句提示 type 1:太棒了  2:真不错  3:真是惊喜  4:太牛了  5:非常棒  6:太好了  7:点攒*/
    public showSpeakTip(type:number):void{
        this["speakTip"].tip.gotoAndStop(type-1);
        this["speakTip"].play(1);
    }
}