class Base extends MC{
    //---------------------------------------------------------编辑器的属性接口及方法接口定义----------------------------------------------------
    private ATTRIBUTES_PAGE = [
        "ATTRIBUTES_PAGE_START",
        "title---['3加4等于多少？','5加2等于多少？']---此游戏题的题目。",
		"options---[[7,5,6],[6,7,5]]---此游戏题的选项。",
		"answer---[[1,2]]---此游戏题的答案。",
        "ATTRIBUTES_PAGE_END"
    ];
	private METHOD_PAGE = [
        "METHOD_PAGE_START",
        "submitAnswer---null---提交答案。",
        "playItem---['item0','label0']---播放当前视图中的一个对象实例。",
        "switchView---null---切换到下一个视图。",
        "METHOD_PAGE_END"
    ];
    //-------------------------------------------------------------------------------------------------------------------------------------------

    /**提交答案数组 */
    private questionJson: Array<any> = [];
    /** 是否已经提交过答案 */
    private hasSubmit: boolean = false;

    constructor(){ super(); }
    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
        setParentMsgBackcall(this.handler, this);
        if(this["bg"]) this.mouseEnabled = true;
	}

    /** 由app中调用执行相应的方法，时间点事件的回调方法。
     * param app中传来的需要执行的方法与参数。 */
    public handler(str:string=""):void{
        var arr = str.split("||");
        var f:string = ""+arr[0];
        var p:string = arr.length > 1 ? arr[1] : null;
        p ?  this[f](p) : this[f]();
    }

    /** 播放特定的实例。
     * nameAndLabel 要播放的实例名与标签组合的字符串。*/
    public playItem(nameAndLabel:string):void{
        var arr = nameAndLabel.split("&");
        var itemName:string = arr[0];
        var frameOrLabel:string = arr[1];
        if(frameOrLabel){
            this[itemName].gotoAndPlay(frameOrLabel);
        }else{
            this[itemName].gotoAndPlay(0);
        }
    }

    /** 同一页PPT中，切换到下一视图（下一帧）。
     * frameLabel 主场景时间轴上的一个标签或帧缩影。*/
    public switchView(frameLabel:string=null):void{
        if(frameLabel == null){
            if(this.currentFrame < this.totalFrames-1) this.gotoAndStop(this.currentFrame+1);
        }else{
            this.gotoAndStop(frameLabel);
        }
    }

    /** 设置根视图是否可点 */
    public enableTouch(b:string="true"):void{
        touchRootEnabled(b == "true");
    }

    /** 由app调用，执行页面卸载前的清理 */
    public destroy():void{
    }
}