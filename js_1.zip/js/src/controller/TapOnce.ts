class TapOnce extends MC{
    //---------------------------------------------------------编辑器的属性接口及方法接口定义----------------------------------------------------
    private ATTRIBUTES_PAGE = [
        "ATTRIBUTES_PAGE_START",
        "title---['3加4等于多少？','5加2等于多少？']---此游戏题的题目。",
		"options---[[7,5,6],[6,7,5]]---此游戏题的选项。",
		"answer---[[1,2]]---此游戏题的答案。",
        "ATTRIBUTES_PAGE_END"
    ];
	private METHOD_PAGE = [
        "METHOD_PAGE_START",
        "submitAnswer---null---提交答案。",
        "playItem---['item0','label0']---播放当前视图中的一个对象实例。",
        "switchView---null---切换到下一个视图。",
        "METHOD_PAGE_END"
    ];
    //-------------------------------------------------------------------------------------------------------------------------------------------

    /** 是否开启实例浮动，默认为false。 */
    public isFloat:boolean;
    /** 本题的最高得分，默认为3分。 */
    public maxScore:number;
    
    /**提交答案数组 */
    private questionJson: Array<any> = [];
    /** 是否已经提交过答案 */
    private hasSubmit: boolean = false;
    /** 可点击的实例 */
    private tapItemArr:Array<createjs.MovieClip>;
    /** 如果选项需要浮动，则指向浮动的ID */
    private floatId:number;

    constructor(){ super(); }
    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
        this.isFloat = false;
        this.maxScore = 3;
        this.tapItemArr = [];
	}

     /** 此方法不一定在初始化方法中调用，也可能是在界面中调用。 */
    public init():void{
        //注册App事件处理函数
        setParentMsgBackcall(this.handler, this);
        //设置根视图不可点
        touchRootEnabled(false);
        //设置本练习的总分
        setAnswerScore(this.maxScore);

        //设置背景点击侦听处理
        var bg:createjs.MovieClip = this.getChildByName("bg") as createjs.MovieClip;
        if(bg) bg.on(EventType.CLICK, this.bgHandler, this);
        //设置内容区点击侦听处理
        var ca:createjs.MovieClip = this.getChildByName("ca") as createjs.MovieClip;
        if(ca) ca.on(EventType.CLICK, this.caHandler, this);
        //过滤可点击的实例（实例名与tap开始，后面加缩影，如：tap0），
        var item:createjs.MovieClip;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i) as createjs.MovieClip;
             if(item.name && item.name.substr(0, 3) == "tap"){
                 item.on(EventType.CLICK, this.tapHandler, this);
                 this.tapItemArr.push(item);
             }
        }
        
        //设置所有选择的浮动
        if(this.isFloat) this.floatId = MCUtils.setFloat(this.tapItemArr);
    }

    /** 点在背景上，说明是乱点 */
    private bgHandler(e:createjs.MovieClip):void{
        if(answerScore == 1){
            //作答次数已用完，播放纠正节点的未完成分支
            //VideoHelper.playCorrect(1);
        }else{
            //VideoHelper.playWrong();
        }
    }

    /** 点在内容区上，他没点到选项，点偏了 */
    private caHandler(e:createjs.MovieClip):void{
        //VideoHelper.playDeviate(-1);
    }

    /** 当点击实例时 */
    private tapHandler(e:createjs.MouseEvent):void{
        //作答结束，屏蔽界面操作
        //touchRootEnabled(false);
        //播放正确的反馈
        var item:createjs.MovieClip = e.currentTarget;
        gotoLabelAndPlay(item, "right");
        gotoLabelAndPlay(this, "right");
        //播放正确提示与得分情况(纠正)
        var arr = [];
        arr.push(VideoType.RIGHT+"&"+getBranchIndexByScore());
        arr.push(VideoType.CORRECT+"&2");
        //VideoHelper.playArr(arr, false, false, false, true);
        var n = parseInt(item.name.charAt(3))+1;
        vp.play(n+".mp4");
    }


    /** 由app中调用执行相应的方法，时间点事件的回调方法。
     * param app中传来的需要执行的方法与参数。 */
    public handler(str:string=""):void{
        var arr = str.split("||");
        var f:string = ""+arr[0];
        var p:string = arr.length > 1 ? arr[1] : null;
        p ?  this[f](p) : this[f]();
    }
    
    /** 播放特定的实例。
     * nameAndLabel 要播放的实例名与标签组合的字符串。*/
    public playItem(nameAndLabel:string):void{
        var arr = nameAndLabel.split("&");
        var itemName:string = arr[0];
        var frameOrLabel:string = arr[1];
        if(frameOrLabel){
            this[itemName].gotoAndPlay(frameOrLabel);
        }else{
            this[itemName].gotoAndPlay(0);
        }
    }

    /** 同一页PPT中，切换到下一视图（下一帧）。
     * frameLabel 主场景时间轴上的一个标签或帧缩影。*/
    public switchView(frameLabel:string=null):void{
        if(frameLabel == null){
            if(this.currentFrame < this.totalFrames-1) this.gotoAndStop(this.currentFrame+1);
        }else{
            this.gotoAndStop(frameLabel);
        }
    }

    /** 由app调用，执行页面卸载前的清理 */
    public destroy():void{
        var bg:createjs.MovieClip = this.getChildByName("bg") as createjs.MovieClip;
        if(bg) bg.removeAllEventListeners(EventType.CLICK);
        var ca:createjs.MovieClip = this.getChildByName("ca") as createjs.MovieClip;
        if(ca) ca.removeAllEventListeners(EventType.CLICK);
        if(this.isFloat) MCUtils.clearFloat(this.floatId);
        if(this.tapItemArr){
            for(var i:number=0; i<this.tapItemArr.length ; i++){
                this.tapItemArr[i].removeAllEventListeners(EventType.CLICK);
            }
        }
        this.tapItemArr = null;
    }
}