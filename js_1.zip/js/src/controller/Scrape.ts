/** 刮开(createjs.AlphaMaskFilter透明度遮罩滤镜的应用) */
class Scrape extends MC{
	//---------------------------------------------------------编辑器的属性接口及方法接口定义----------------------------------------------------
    private ATTRIBUTES_PAGE = [
        "ATTRIBUTES_PAGE_START",
        "title---['3加4等于多少？','5加2等于多少？']---此游戏题的题目。",
		"options---[[7,5,6],[6,7,5]]---此游戏题的选项。",
		"answer---[[1,2]]---此游戏题的答案。",
        "ATTRIBUTES_PAGE_END"
    ];
	private METHOD_PAGE = [
        "METHOD_PAGE_START",
        "submitAnswer---null---提交答案。",
        "METHOD_PAGE_END"
    ];

	private LIST_INST = [
        "LIST_INST_START",
        "Scrape_Instance",
        "LIST_INST_END"
    ];
	private ATTRIBUTES_Scrape_Instance = [
        "ATTRIBUTES_Scrape_Instance_START",
        "eraserSize---40---黑板擦的大小。",
		"MouseFollower---默认---鼠标跟随物，默认为系统自己画的圆。",
		"BlurParam---[24, 24, 2]---图片的模糊程度[X模糊，Y模糊，质量]。",
        "ATTRIBUTES_Scrape_Instance_END"
    ];
    //-------------------------------------------------------------------------------------------------------------------------------------------

    /**提交答案数组 */
    private questionJson;
    /** 是否已经提交过答案 */
    private hasSubmit:boolean;

	private addBtn:createjs.MovieClip;
	private delBtn:createjs.MovieClip;

    constructor(){ super(); }
	/** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
		this.questionJson = [];
		this.hasSubmit = false;
	}
	
	/** 覆盖父级，由系统在第一帧上的代码执行完后调用。 */
	public init() {
		this.addBtn = this["addDragBtn"];
		this.delBtn = this["removeDragBtn"];
		this.addBtn.on("click", this.addBtnHandler, this);
		this.delBtn.on("click", this.delBtnHandler, this);
	}

	private addBtnHandler(e:createjs.MouseEvent):void{
		this.addDrag();
	}

	private delBtnHandler(e:createjs.MouseEvent):void{
		this.stopDrag();
	}

	public addDrag():void{
		var item:Scrape_Instance;
		for(var i:number=0; i<this.numChildren; i++){
			item = this.getChildAt(i) as Scrape_Instance;
			if(item instanceof Scrape_Instance){
				item.addListener();
			}
		}
	}

	public stopDrag():void{
		var item:Scrape_Instance;
		for(var i:number=0; i<this.numChildren; i++){
			item = this.getChildAt(i) as Scrape_Instance;
			if(item instanceof Scrape_Instance){
				item.removeListener();
			}
		}
	}


	 /** 由app调用，执行页面卸载前的清理 */
    public destroy():void{
	}
}

class Scrape_Instance extends MC{
	private isDrawing;
	private drawingCanvas;
	private oldPt;
	private oldMidPt;
	private blur;
	private circle:createjs.Shape;
	private picBg;

    constructor(){ super(); }
	/** 覆盖父级，构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
	}

	/** 覆盖父级，由系统在第一帧上的代码执行完后调用。 */
	public init() {
		//如果与此视图对应的底图存在，则模糊底图(底图是此图不可见时显示的图)
		if(this.parent["picBg"]){
			this.picBg = this.parent["picBg"];
			this.picBg.filters = [new createjs.BlurFilter(24, 24, 2), new createjs.ColorMatrixFilter(new createjs.ColorMatrix(60))];
			this.picBg.cache(0, 0, this.width, this.height);
		}
		//创建遮罩绘制层
		this.drawingCanvas = new createjs.Shape();
		this.drawingCanvas.cache(0, 0, this.width, this.height);
		//创建一个透明度遮罩滤镜
		var maskFilter = new createjs.AlphaMaskFilter(this.drawingCanvas.cacheCanvas);
		this.filters = [maskFilter];
		this.cache(0, 0, this.width, this.height);
		//创建鼠标移动跟随
		this.circle= new createjs.Shape(new createjs.Graphics().beginFill("#666666").drawCircle(0, 0, 25));
		this.circle.cursor = "pointer";
		this.circle.mouseEnabled = false;
		this.parent.addChild(this.circle);

		this.addListener();
	}

	public addListener():void{
		if(this.hasEventListener("mousedown")) return;
		this.on("mousedown", this.down, this);
		this.on("pressmove", this.move, this);
		this.on("pressup", this.up, this);
	}

	public removeListener():void{
		if(this.hasEventListener("mousedown") == false) return;
		this.removeAllEventListeners("mousedown");
		this.removeAllEventListeners("pressmove");
		this.removeAllEventListeners("pressup");
	}


	private down(e:createjs.MouseEvent):void {
		this.oldPt = new createjs.Point(e.localX, e.localY);
		this.oldMidPt = this.oldPt;
		this.isDrawing = true;
	}

	private move(e:createjs.MouseEvent):void {
		this.circle.x = this.x+e.localX-this.regX;
		this.circle.y = this.y+e.localY-this.regY;
		//this.circle.x = stage.mouseX;
		//this.circle.y = stage.mouseY;
		if (!this.isDrawing) {
			stage.update();
			return;
		}

		var midPoint = new createjs.Point(this.oldPt.x + e.localX >> 1, this.oldPt.y + e.localY >> 1);
		this.drawingCanvas.graphics.clear()
			.setStrokeStyle(40, "round", "round")
			.beginStroke("rgba(0,0,0,0.1)")
			.moveTo(midPoint.x, midPoint.y)
			.curveTo(this.oldPt.x, this.oldPt.y, this.oldMidPt.x, this.oldMidPt.y);
		this.oldPt.x = e.localX;
		this.oldPt.y = e.localY;
		this.oldMidPt.x = midPoint.x;
		this.oldMidPt.y = midPoint.y;
		this.drawingCanvas.updateCache("source-over");
		this.updateCache();
		stage.update();
	}

	private up(e:createjs.MouseEvent):void {
		this.isDrawing = false;
	}
}