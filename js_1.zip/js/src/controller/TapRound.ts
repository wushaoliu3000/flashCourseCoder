class TapRound extends MC{
    //---------------------------------------------------------编辑器的属性接口及方法接口定义----------------------------------------------------
    private ATTRIBUTES_PAGE = [
        "ATTRIBUTES_PAGE_START",
        "title---['3加4等于多少？','5加2等于多少？']---此游戏题的题目。",
		"options---[[7,5,6],[6,7,5]]---此游戏题的选项。",
		"answer---[[1,2]]---此游戏题的答案。",
        "ATTRIBUTES_PAGE_END"
    ];
	private METHOD_PAGE = [
        "METHOD_PAGE_START",
        "submitAnswer---null---提交答案。",
        "playItem---['item0','label0']---播放当前视图中的一个对象实例。",
        "switchView---null---切换到下一个视图。",
        "METHOD_PAGE_END"
    ];
    //-------------------------------------------------------------------------------------------------------------------------------------------
    /** 本题的最高得分，默认为3分。 */
    public maxScore:number;
    /** 每一轮的答案数组 */
	public answerArr:Array<any>;
	/** 每一轮的每一个选项上显示的内容 */
    public answerTipArr:Array<any>;
    /** 每一轮的每一个选项上携带的内容 */
    public answerContentArr:Array<any>;
    /** 如果自动开始下一轮的时间大于0(以秒为单位)，则在指定的时间后自动开始下一轮 */
    public autoStartTime:number;
    /** 是否允许试错 */
    public isAllowError:boolean;
    /** 如果选项需要浮动，则指向浮动的ID，浮动的开启与关闭，一般在PPT页面中设置。 */
    public floatId:number;
    /** 延时结束时间，等等动画执行完成。 */
    public delayEndTime:number;
	
	/**提交答案数组 */
    private questionJson:Array<any>;
    /** 是否已经提交过答案 */
    private hasSubmit:boolean;
    /** 可点击的实例 */
    private tapItemArr:Array<createjs.MovieClip>;
	/** 当前轮的答案数组 */
	private curAnswerArr:Array<any>;
	/** 当前轮数 */
	private curRoundIndex:number;
	/** 总的轮数 */
	private totalRounds:number;
    

    constructor(){ super(); }
    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
        this.floatId = -1;
        this.maxScore = 3;
        this.autoStartTime = -1;
        this.isAllowError = true;
        this.delayEndTime = 2000;
        this.hasSubmit = false;
		this.questionJson = [];
        this.tapItemArr = [];
	}

     /** 此方法不一定在初始化方法中调用，也可能是在界面中调用。 */
    public init():void{
        //注册App事件处理函数
        setParentMsgBackcall(this.handler, this);
        //设置本练习的总分
        setAnswerScore(this.maxScore);

		//设置总的轮数
        if(this.answerArr) this.totalRounds = this.answerArr.length;
		//初始化轮数缩影
		this.curRoundIndex = 0;

        //设置背景点击侦听处理
        var bg:createjs.MovieClip = this.getChildByName("bg") as createjs.MovieClip;
        if(bg) bg.on(EventType.CLICK, this.bgHandler, this);
        //设置内容区点击侦听处理
        var ca:createjs.MovieClip = this.getChildByName("ca") as createjs.MovieClip;
        if(ca) ca.on(EventType.CLICK, this.caHandler, this);
        //过滤可点击的实例（实例名与tap开始，后面加缩影，如：tap0），
        var item:createjs.MovieClip;
        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i) as createjs.MovieClip;
             if(item.name && item.name.substr(0, 3) == "tap"){
                 item.on(EventType.CLICK, this.tapHandler, this);
                 this.tapItemArr.push(item);
             }
        }

        //开始第一轮
        this.start();
    }

	/** 开始新的一轮 */
	public start():void{
        var item;
        var a;
		if(this.answerArr){
            this.curAnswerArr = this.answerArr[this.curRoundIndex];
        } 
        if(this.answerContentArr){
            var contentArr = this.answerContentArr[this.curRoundIndex];
            a = MCUtils.getRandomArr(contentArr.length);
            //console.log(this.curRoundIndex+" "+a[0]+" "+a[1]);
            //console.log(this.curRoundIndex+" "+contentArr[a[0]]+" "+contentArr[a[1]]);
            for(var i=0; i<contentArr.length; i++){
                item = this.tapItemArr[i];
                item["tap"] = false;
                item["content"] = contentArr[a[i]];
                if(item["flag"]){
                    item["flag"].gotoAndStop(a[i]);
                } 
                if(item["randomBg"]){
                    item["randomBg"].gotoAndStop(Math.floor(Math.random()*item["randomBg"].totalFrames));
                }
            }
        }
        if(this.answerTipArr){
            var tipArr = this.answerTipArr[this.curRoundIndex];
            item = this.tapItemArr[i];
            for(var i=0; i<tipArr.length; i++){
                if(item["tipTf"]) item["tipTf"].text = tipArr[i];
            }
        }
        gotoLabelAndPlay(this, "start");
	}

    /** 当点击实例时 */
    private tapHandler(e:createjs.MouseEvent):void{
        var item:createjs.MovieClip = e.currentTarget;
        var curAnswer:string = item["content"];
        item["tap"] = true;
        if(this.judegAnswer(curAnswer) == true){
            gotoLabelAndPlay(item, "right");
            gotoLabelAndPlay(this, "right");
            this.tapAllRightItem();
            VideoHelper.playTipRight();
        }else{
            gotoLabelAndPlay(item, "wrong");
            gotoLabelAndPlay(this, "wrong");
            if(this.isAllowError == false) this.endRound(false);
            VideoHelper.playTipWrong();
        }
        
        if(this.curRoundIndex == this.totalRounds){
            VideoHelper.playRight();
        }
    }

    /** 判断选择的项是否是正确选项 */
    private judegAnswer(answer: string): boolean {
        for (var i:number=0; i<this.curAnswerArr.length; i++) {
            if (this.curAnswerArr[i] == answer) return true;
        }
        return false;
    }

    /** 判断是否所有正确项都被点击完了 */
    private tapAllRightItem():void{
        var b,v,item;
        for(var i:number=0; i<this.tapItemArr.length; i++) {
            item = this.tapItemArr[i];
            //假如是正确答案，但没有点过，说明没选完
            b = this.judegAnswer(item["content"]);
            v = item["tap"] == false;
            if(b && v) return;
        }
        this.endRound(true);
    }

    /** 结束一轮，或结束游戏 */
    private endRound(isRight:boolean):void{
        if(this.curRoundIndex == this.totalRounds-1){
            //作答结束，屏蔽界面操作
            touchRootEnabled(false);
            //把结果与纠正并成一组播放
            setTimeout(()=>{
                var e0 = VideoType.END+"&"+getBranchIndexByScore();
                var e1 = VideoType.CORRECT+"&2";
                VideoHelper.playArr([e0, e1], false, false, false, true);
            }, this.delayEndTime);
            gotoLabelAndPlay(this, "finish");
        }else{
            this.curRoundIndex++;
            if(this.autoStartTime == 0){
                this.start();
            } else if(this.autoStartTime > 0){
                setTimeout(()=>{this.start();}, this.autoStartTime*1000);
            }
        }
    }

    /** 点在背景上，说明是乱点 */
    private bgHandler(e:createjs.MovieClip):void{
        if(answerScore == 1){
            //作答次数已用完，播放纠正节点的未完成分支
            VideoHelper.playCorrect(1);
        }else{
            VideoHelper.playWrong(-1);
        }
        //loadPpt("Base,pvpScore,0", "true");
    }

    /** 点在内容区上，他没点到选项，点偏了 */
    private caHandler(e:createjs.MovieClip):void{
         if(answerScore == 1){
            //作答次数已用完，播放纠正节点的未完成分支
            VideoHelper.playCorrect(1);
        }else{
            VideoHelper.playDeviate(-1);
        }
    }


    /** 由app中调用执行相应的方法，时间点事件的回调方法。
     * param app中传来的需要执行的方法与参数。 */
    public handler(str:string=""):void{
        var arr = str.split("||");
        var f:string = ""+arr[0];
        var p:string = arr.length > 1 ? arr[1] : null;
        p ?  this[f](p) : this[f]();
    }

    /** 播放特定的实例。
     * nameAndLabel 要播放的实例名与标签组合的字符串。*/
    public playItem(nameAndLabel:string):void{
        var arr = nameAndLabel.split("&");
        var itemName:string = arr[0];
        var frameOrLabel:string = arr[1];
        if(frameOrLabel){
            this[itemName].gotoAndPlay(frameOrLabel);
        }else{
            this[itemName].gotoAndPlay(0);
        }
    }

    /** 同一页PPT中，切换到下一视图（下一帧）。
     * frameLabel 主场景时间轴上的一个标签或帧缩影。*/
    public switchView(frameLabel:string=null):void{
        if(frameLabel == null){
            if(this.currentFrame < this.totalFrames-1) this.gotoAndStop(this.currentFrame+1);
        }else{
            this.gotoAndStop(frameLabel);
        }
    }


    /** 由app调用，执行页面卸载前的清理 */
    public destroy():void{
        var bg:createjs.MovieClip = this.getChildByName("bg") as createjs.MovieClip;
        if(bg) bg.removeAllEventListeners(EventType.CLICK);
        var ca:createjs.MovieClip = this.getChildByName("ca") as createjs.MovieClip;
        if(ca) ca.removeAllEventListeners(EventType.CLICK);
        if(this.floatId > 0) MCUtils.clearFloat(this.floatId);
        if(this.tapItemArr){
            for(var i:number=0; i<this.tapItemArr.length ; i++){
                this.tapItemArr[i].removeAllEventListeners(EventType.CLICK);
            }
        }
        this.tapItemArr = null;
    }
}