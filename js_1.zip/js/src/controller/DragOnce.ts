class DragOnce extends MC{
    //---------------------------------------------------------编辑器的属性接口及方法接口定义----------------------------------------------------
    private ATTRIBUTES_PAGE = [
        "ATTRIBUTES_PAGE_START",
        "title---['3加4等于多少？','5加2等于多少？']---此游戏题的题目。",
		"options---[[7,5,6],[6,7,5]]---此游戏题的选项。",
		"answer---[[1,2]]---此游戏题的答案。",
        "careResult---true||false---是否关心做题的结果。",
        "isDisabled---true||false---此数组 记录了每一轮应该点击的正确答案字符串。",
        "answerType---1||2||3||4---答案类型 1:提示所有记录下来的答案， 2:只要选对了一个正确答案就算对， 3:所有正确答案都选择了才算对， 4:只有不同类型的正确答案都有才算对。",
        "submitEverytime---true||false---是否为每一次选择都提交答案。",
        "tipTime---1000---定时提示，如果此值存在，则在指定的时间后执行提示动效。",
        "isAllowError---true||false---是否允许试错。",
        "isDragToTopLevel---true||false---拖动时，是否让拖动对象置顶。",
        "isReboundEffect---true||false---返回原位时，是否要反弹效果。",
        "isFixedToBottom---false||true---拖动对象被固定时，是否置底。",
        "isFixedToInitPosition---false||true---拖动对象被固定时，是否回到初始位置。",
        "isCircleShape---false||true---是否需要在做题前，先圈出一个图形。",
        "ATTRIBUTES_PAGE_END"
    ];
    private METHOD_PAGE = [
        "METHOD_PAGE_START",
        "init---null---设置界面是否可操作。",
        "submitAnswer---默认---提交答案。默认表示提交页面属性中配置的答案，也可以填写其它答案。",
        "test1---['wsl',3]---停止所有声音。",
		"test2---256---停止所有声音。",
        "METHOD_PAGE_END"
    ];

    private LIST_INST = [
        "LIST_INST_START",
        "DragOnce_Drag",
        "DragOnce_Hit",
        "LIST_INST_END"
    ];
    private ATTRIBUTES_DragOnce_Drag = [
        "ATTRIBUTES_DragOnce_Drag_START",
        "index---1---此拖动对象的缩影。",
        "data---[2,5]---携带的参数。",
        "hits---['hit1','hit2']---此拖动对象需要碰撞的对象，可以有多个。",
        "bindObj---[]---绑定对象，可以有多个。以拖动对象关联的对象，当拖动对象的状态改变时，可以相应的改变绑定对象的状态。",
        "dragSound---1---开始拖动此实例时播放指定次数声音，拖动放开时立刻停止播放。",
        "fixedSound---1---拖动的实例被固定时播放指定次数的声音。",
        "ATTRIBUTES_DragOnce_Drag_END"
    ];
    private METHOD_DragOnce_Drag = [
        "METHOD_DragOnce_Drag_START",
        "correct---null---纠错。",
        "METHOD_DragOnce_Drag_END"
    ];

    private ATTRIBUTES_DragOnce_Hit = [
        "ATTRIBUTES_DragOnce_Hit_START",
        "index---1---此碰撞对象的缩影。",
        "data---[2,5]---携带的参数。",
        "ATTRIBUTES_DragOnce_Hit_END"
    ];
    //-------------------------------------------------------------------------------------------------------------------------------------------

    /**提交答案数组 */
    private questionJson: Array<any>;
    /** 是否已经提交过答案 */
    private hasSubmit: boolean = false;
    
    /** 此数组 记录了每一轮应该点击的正确答案字符串。 */
    public answers: Array<any>;
    /** 是否在选择了所有的正确答案之后就屏蔽操作 */
    public isDisabled: boolean = true;
    /** 答案类型 1:提示所有记录下来的答案， 2:只要选对了一个正确答案就算对， 3:所有正确答案都选择了才算对， 4:只有不同类型的正确答案都有才算对 */
    public submitAnswerType: number = 4;
    /** 是否为每一次选择都提交答案 */
    public isSubmitAnswerEverytime:boolean = true;
    /** 定时提示，如果此值存在，则在指定的时间后执行提示动效 */
    public tipTime:number = -1;
    /** 是否允许试错 */
    public isAllowError:boolean = true;
    /** 是否需要在做题前，先圈出一个图形 */
    public isCircleShape:boolean = false;

    /** 记录点击对象的初始位置，用于随机交换位置，如果开始动效的最后一帧上的end标签，则在此标签帧时执行交换位置 */
    private hitArr: Array<any>;
    /** 可点击的实例 */
    private tapItemArr;

    /** 是否所有正确答案都选择了 */
    private isSelectAllAnswer:boolean = false;
    /** 存储已经选择的正确项 */
    private selectedAnswerArr = [];
    /** 延时提示的ID */
    private tipTimeId:number = -1;

    /** 当前已经固定的可拖动实例数目 */
    private fixedCnt:number;
    /** 可以拖动的实例数 */
    private numDragItem:number;

    constructor(){ super(); }
    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
        this.questionJson = [];
        this.hasSubmit = false;
        this.isDisabled = true;
        this.submitAnswerType = 4;
        this.isSubmitAnswerEverytime = true;
        this.tipTime = -1;
        this.isAllowError = true;
        this.isCircleShape = false;
        this.hitArr = [];
        this.tapItemArr = [];
        this.isSelectAllAnswer = false;
        this.selectedAnswerArr = [];
        this.tipTimeId = -1;
        this.fixedCnt = 0;
        this.numDragItem = 0;
	}

    /** 此方法不一定在初始化方法中调用，也可能是在界面中调用。 */
    public init():void{
        var item:DragOnce_Drag;
        /*for(var i=0; i<10; i++){
            var drag = createMC("苹果");
            drag.parent = this;
            this.addChild(drag);
        }*/

        for(var i:number=0; i<this.numChildren; i++){
            item = this.getChildAt(i) as DragOnce_Drag;
             if(item instanceof DragOnce_Drag){
                 this.tapItemArr.push(item);
                 item.on("startDrag", this.startDrag, this);
                 item.on("endDrag", this.endDrag, this);
                 this.numDragItem++;
             }
        }
    }

    private startDrag(e){
        var item:DragOnce_Drag = e.target;
    }
    private endDrag(e){
        var item:DragOnce_Drag = e.target;
        var hit:DragOnce_Hit = this["hit"];
        if(hitTestObj(item, hit)){
            this["downApple"].gotoAndPlay(1);
            if(this.fixedCnt == this.numDragItem-1){
                if(this["lihua"]) this["lihua"].play();
                if(this["backcallMC"]) this["backcallMC"].gotoAndStop(1);
            }
            item.visible = false;
            this.fixedCnt++;
        }
    }
}

/** -----------------------------------定义此控制器用到的实例类，及其公有属性与方法----------------------------- */
class DragOnce_Drag extends MC{
    public index:number;
    public word:string

    private oldX:number;
    private oldY:number;
    private isMove:boolean;

    constructor(){ super(); }
    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
        this.index = 0;
        this.word = "你好";
        this.oldX = 0;
        this.oldY = 0;
        this.isMove = false;
	}

    public init():void{
        this.on("mousedown", this.downHandler, this);
        this.on("pressmove", this.moveHandler, this);
        this.on("pressup", this.upHandler, this);
    }

     private downHandler(e:createjs.MouseEvent){
        this.oldX = e.localX;
        this.oldY = e.localY;
        this.parent.addChild(this);
    }

    private moveHandler(e:createjs.MouseEvent){
        this.x += e.localX - this.oldX;
		this.y += e.localY - this.oldY;
		this.oldX = e.localX;
        this.oldY = e.localY;
        if(this.isMove == false){
            this.isMove = true;
            this.dispatchEvent("startDrag", this);
        }
        stage.update();
    }

    private upHandler(e:createjs.MouseEvent){
        if(this.isMove == true){
            this.isMove = false;
            this.dispatchEvent("endDrag", this);
        }
    }
}

class DragOnce_Hit extends MC{

    constructor(){ super(); }
    /** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		super.construct();
	}

    public init():void{

    }
}