class MC extends createjs.MovieClip{
	/** 元件的宽度 */
	public width;
	/** 元件的高度 */
	public height;
	/** 此类控制的可视对象 */
	public mc:createjs.MovieClip;

	public constructor() { super(); }

	/** 构造时由子类调用，所有的属性初始化都在此函数中，不要在属性定义时初始化，因为构造函数不会被执行 */
	public construct(){
		if(this["nominalBounds"]){
			this.width = this["nominalBounds"]["width"];
			this.height = this["nominalBounds"]["height"];
		}else if(this["frameBounds"]){
			this.width = this["frameBounds"]["width"];
			this.height = this["frameBounds"]["height"];
		}else{
			this.width = 0;
			this.height = 0;
		}
		this._oldX = 0;
        this._oldY = 0;
        this._isMove = false;
	}

	/** 子类初始完成时由子类调用（延时一帧后调用，保证子类第一帧的代码执行完成） */
    public initiate(mc:createjs.MovieClip):void{
        this.mc = mc;
		this.init();
    }

	public init():void{
	}

	//--------------------------------------------------添加拖动，让一个物体可以拖动，并处发相应的事件--------------------------------
	private _oldX:number;
    private _oldY:number;
    private _isMove:boolean;
	/** 添加拖动，让一个物体可以拖动，并处发相应的事件 */
    public addDrag(item:createjs.MovieClip, dragEnd=null, dragMove=null, dragStart=null, down=null):void{
        item.on("mousedown", this._downHandler, this);
        item.on("pressmove", this._moveHandler, this);
        item.on("pressup", this._upHandler, this);
        if(dragEnd) item.on("dragEnd", dragEnd, this);
        if(dragMove) item.on("dragMove", dragMove, this);
        if(dragStart) item.on("dragStart", dragStart, this);
		if(down) item.on("down", down, this);
    }
	/** 删除拖动及对应的事件 */
    public delDrag(item:createjs.MovieClip):void{
        item.removeAllEventListeners("mousedown");
        item.removeAllEventListeners("pressmove");
        item.removeAllEventListeners("pressup");
        item.removeAllEventListeners("dragEnd");
        item.removeAllEventListeners("dragMove");
        item.removeAllEventListeners("dragStart");
		item.removeAllEventListeners("down");
    }
    private _downHandler(e:createjs.MouseEvent){
        var item = e.currentTarget;
        this._oldX = e.localX;
        this._oldY = e.localY;
        item.parent.addChild(item);
		e.currentTarget.dispatchEvent("down");
    }
    private _moveHandler(e:createjs.MouseEvent){
        if(this._isMove == false && Math.abs(this._oldX-e.localX)>5 || Math.abs(this._oldY-e.localY)>5){
            this._isMove = true;
            e.currentTarget.dispatchEvent("dragStart");
        }
        var item = e.currentTarget;
        item.x += e.localX - this._oldX;
		item.y += e.localY - this._oldY;
		this._oldX = e.localX;
        this._oldY = e.localY;
        e.currentTarget.dispatchEvent("dragMove");
    }
    private _upHandler(e:createjs.MouseEvent){
        e.currentTarget.dispatchEvent("dragEnd");
    }
	//---------------------------------------------------------------------------------------------------------------------------------

    /** 延时特定的秒跳转到指定的标签或帧。
     * time 要延时的秒数。
     * labelOrFrame 一个帧标签或帧数（缩影从0开始）。
     * playOrStop 跳转后是停止或播放。*/
	public delay(time:number, labelOrFrame:any, playOrStop:string="stop"):void{
        if(playOrStop == "play"){
            setTimeout(this.gotoAndPlay, time*1000, labelOrFrame);
        }else{
            setTimeout(this.gotoAndStop, time*1000, labelOrFrame);
        }
	}

    /** 设置本身是否可点 */
    public enableTouch(b):void{
        if(b == true || b == "true"){
            this.mouseEnabled = true;
            this.mouseChildren = true;
        }else{
            this.mouseEnabled = false;
            this.mouseChildren = false;
        }
    }
}

/** 提供了一些影片剪辑实例操作的实用函数。 */
class MCUtils{
    /** 抖动一个实例（位置抖动）。
     * mc 要抖动的实例。
     * time 抖动时间。
     * amplitude 抖动幅度。*/
    static shakePosition(mc:createjs.MovieClip, time:number=1, amplitude:number=5):void{
        if(mc["shakeId"] && mc["shakeId"] > 0) return;
        if(time < 0) return;
        if(amplitude > 100) amplitude = 100;
        var cnt = 0;
        var initX = mc.x;
        var initY = mc.y;
        mc["shakeId"] = setInterval(()=>{
            if(cnt%2 == 0){
                mc.x = initX;
                mc.y = initY;
            }else{
                mc.x += (Math.random()>0.5?amplitude:-amplitude);
                mc.y += (Math.random()>0.5?amplitude:-amplitude);
            }
            cnt++;
            if(cnt > time*20){
                clearInterval(mc["shakeId"]);
                mc["shakeId"] = -1;
                mc.x = initX;
                mc.y = initY;
            }
        }, 50);
    }

    /** 抖动一个实例（缩放抖动）。
     * mc 要抖动的实例。
     * time 抖动时间。
     * scale 缩放幅度。*/
    static shakeZoom(mc:createjs.MovieClip, time:number=1, scale:number=1.5):void{
        if(mc["shakeId"] && mc["shakeId"] > 0) return;
        if(time < 0) return;
        if(scale > 3) scale = 3;
        time = time/2;
        createjs.Tween.get(mc).to({scaleX:scale,scaleY:scale}, time*1000, createjs.Ease.bounceOut).to({scaleX:1,scaleY:1}, time*1000, createjs.Ease.bounceOut);
    }

    /** 闪烁一个实例。
     * mc 要闪烁的实例。
     * time 闪烁时间。
     * alpha 闪烁透明度，0到1之间。*/
    static flicker(mc:createjs.MovieClip, time:number=1, alpha:number=0.2):void{
        if(mc["flickerId"] && mc["flickerId"] > 0) return;
        if(time < 0) return;
        if(alpha < 0) alpha = 0;
        if(alpha > 1) alpha = 1;
        var cnt = 0;
        mc["flickerId"] = setInterval(()=>{
            if(cnt%2 == 0){
                mc.alpha = 1;
            }else{
                mc.alpha = alpha;
            }
            cnt++;
            if(cnt > time*20){
                clearInterval(mc["flickerId"]);
                mc["flickerId"] = -1;
                mc.alpha = 1;
            }
        }, 50);
    }

    /** 让一组MC实例实现飘动效果。返回飘动间隔回调的ID，用于停止飘动。 */
    static setFloat(mcArr:Array<any>, type:number=0):number{
        for(var i=0; i<mcArr.length; i++){
            mcArr[i]["angle"] = Math.ceil(Math.random()*360);
        }
        var id = setInterval(floatHandler, 50);
        function floatHandler(e):void{
            var item;
            for(var i=0; i<mcArr.length; i++){
                item = mcArr[i];
                item.angle += 10;
                if(type == 0){
                    item.x += Math.sin(0.017*item.angle)*1;
                    item.y += Math.sin(0.017*item.angle)*2;
                }else if(type == 1){
                    item.x += Math.sin(0.017*item.angle)*1;
                    item.y += Math.cos(0.017*item.angle)*2;
                }else if(type == 2){
                    item.x += Math.sin(0.017*item.angle)*2;
                    item.y += Math.cos(0.017*item.angle)*1;
                }
            }
        }
        return id;
    }
    /** 清理飘动效果 */
    static clearFloat(id:number):void{
        clearInterval(id);
        trace("清理: "+id);
    }

    /** 随机交换一组实例的位置 */
    static randomPosition():void{

    }

    /** 打乱一个数组中的位置顺序 */
    static randomArr(arr):void{
        function randomsort(a, b) {
            return Math.random()>.5 ? -1 : 1;
        }
        arr.sort(randomsort);
    }

    /** 获取一个指定长度并打乱顺序的数组 */
    static getRandomArr(len:number):Array<number>{
        var arr = [];
        for(var i:number=0; i<len; i++){
            arr.push(i);
        }
        MCUtils.randomArr(arr);
        return arr;
    }
}

/** H5视频播放助手 */
class VideoPlayer {
	private video;
	private bm;
    private videoArr:Array<string>;
    private isPause:boolean = false;
    private arr = ["downApple.mp4","run.mp4","1.mp4","2.mp4","3.mp4","4.mp4","5.mp4","6.mp4","7.mp4","8.mp4","9.mp4"];

	public constructor() {
        //showTrace();
        this.loadConfig();
        this.createBtn();
	}

    /** 加载配置文件，配置文件用js存储，避免跨域问题。 */
	private loadConfig(){
		var queue = new createjs.LoadQueue(false);
		queue.on("complete", this.completeHandler, this);
		queue.loadManifest(["current/config.js", "current/course.js"]);
	}
	private completeHandler(e) {
        //trace("配置加载完成 "+courseConfig.teacher);
	}

    /** 创建开始上课按钮 */
    private createBtn(){
		var bg = new createjs.Shape();
		bg.graphics.beginFill("#0");
		bg.graphics.drawRect(0, 0, 100, 100);
		var mc = new createjs.MovieClip();
		mc.addChild(bg);
        mc.x = 500;
	    mc.y = 30;
	    mc.on("click", function(){
            stage.removeChild(mc);
            this.createVideo();
            this.playArr([this.arr[0],this.arr[0]]);
        }, this);
        stage.addChild(mc);
	}

	private createVideo(){
		this.video = document.getElementById("v0");
		var bm = new createjs.Bitmap(this.video);
		this.bm = bm;
        //bm.on("click", ()=>{this.resume();}, this);
		stage.addChildAt(bm, 0);

        loadPpt("Base,downApple,0", false);
		
		this.video.addEventListener('timeupdate', (e)=>{
            /*if(e.timeStamp > this.video.duration*1000-200){
            }*/
            if(e.timeStamp > 4000 && this.isPause == false){
                //this.resume();
            }
		});
		this.video.addEventListener('ended', (e)=>{
            if(this.videoArr && this.videoArr.length > 0){
                this.play(this.videoArr.shift());
            }else{
                loadPpt("Base,run,0", false);
                setTimeout(()=>{touchRootEnabled(true)}, 500);
            }
		});
	}
	
    /** 播放单个视频 */
	public play(uri:string){
        stage.autoClear = false;
        setTimeout(function(){stage.autoClear = true;}, 500);
		this.video.src = "current/video/"+uri;
		this.video.play();
	}

    /** 联播一组视频 */
    public playArr(arr:Array<string>):void{
        this.videoArr = arr;
        this.play(this.videoArr.shift());
    }

    /** 播放与暂停之间切换 */
    public resume():void{
        if(this.video.paused) {
           this.video.play();
           //this.isPause = false;
        }else{
           this.video.pause();
           this.isPause = true;
        }
    }
}

/** 视频分支播放助手，播放当前小节下特定节点的指定分支。 */
class VideoHelper{
    /** 通知APP播放一个提示视频。
     * index 要播放当前小节的提示视频缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放提示中，是否可以执行界面操作。
     * isReduceAnswerScore 是否减少作答得分，默认为false。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playTip(index:number, isWait:boolean=true, enable:boolean=true, isReduceAnswerScore:boolean=false, backCall:Function=null, scope:any=null):void{
        if(isReduceAnswerScore) reduceAnswerScore();
        var arr = [VideoType.TIP+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
    }
    /** 通知APP播放一个选对了的提示视频。
     * index 要播放当前小节的提示视频缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放提示中，是否可以执行界面操作。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playTipRight(index:number=-1, isWait:boolean=true, enable:boolean=true, backCall:Function=null, scope:any=null):void{
        var arr = [VideoType.TIP_RIGHT+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
    }
    /** 通知APP播放一个选错了的提示视频。
     * index 要播放当前小节的提示视频缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放提示中，是否可以执行界面操作。
     * isReduceAnswerScore 是否减少作答得分，默认为false。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playTipWrong(index:number=-1, isWait:boolean=true, enable:boolean=true, isReduceAnswerScore:boolean=true, backCall:Function=null, scope:any=null):void{
        if(isReduceAnswerScore) reduceAnswerScore();
        var arr = [VideoType.TIP_WRONG+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
    }
    /** 通知APP播放乱作答视频，播放时会屏蔽界面操作，每作答错误一次扣一分。
     * index 要播放当前小节的乱作答视频缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放乱作答中，是否可以执行界面操作。
     * isReduceAnswerScore 是否减少作答得分，默认为true。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playSlovenly(index:number=-2, isWait:boolean=true, enable:boolean=false, isReduceAnswerScore:boolean=true, backCall:Function=null, scope:any=null):void{
        if(isReduceAnswerScore) reduceAnswerScore();
        if(index == -2) index = answerWrongNum;
        var arr = [VideoType.SLOVENLY+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
        answerWrongNum++;
    }
    /** 通知APP播放点偏了的视频，播放时会屏蔽界面操作。
     * index 要播放当前小节的点偏了视频缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频，默认为true。
     * enable 播放乱作答中，是否可以执行界面操作。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playDeviate(index:number, isWait:boolean=true, enable:boolean=false, backCall:Function=null, scope:any=null):void{
        var arr = [VideoType.DEVIATE+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
    }
    /** 通知APP播放作答错误视频，播放时会屏蔽界面操作，每作答错误一次扣一分。
     * index 要播放当前小节的作答错误视频缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放作答错误中，是否可以执行界面操作。
     * isReduceAnswerScore 是否减少作答得分，默认为true。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playWrong(index:number=-2, isWait:boolean=true, enable:boolean=false, isReduceAnswerScore:boolean=true, backCall:Function=null, scope:any=null):void{
        if(isReduceAnswerScore) reduceAnswerScore();
        if(index == -2) index = answerWrongNum;
        var arr = [VideoType.WRONG+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
        answerWrongNum++;
    }
    /** 通知APP播放作答正确视频，播放时会屏蔽界面操作。
     * index 要播放当前小节的作答正确视频缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放作答正确中，是否可以执行界面操作。
     * isSendScore 是否向服务器发送我与机器人的得分，默认为true。
     * isUpdate 是否更新得分显示，如果不更新，则由老师发放分数时更新。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playRight(index:number=-2, isWait:boolean=false, enable:boolean=false, isSendScore:boolean=true, isUpdate:boolean=true, backCall:Function=null, scope:any=null):void{
        if(index == -2) index = getBranchIndexByScore();
        var arr = [VideoType.RIGHT+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
        if(isSendScore) setTimeout(sendScoreEvent, 1000, answerScore, getRobotScore(), isUpdate);
    }
    /** 通知APP播放作答结束视频(此题没有错误选项，只要做完就是对的)，播放时会屏蔽界面操作。
     * index 要播放当前小节的作答结束视频缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放作答结束中，是否可以执行界面操作。
     * isSendScore 是否向服务器发送得分，默认为true。
     * isUpdate 是否更新得分显示，如果不更新，则由老师发放分数时更新。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playEnd(index:number=-2, isWait:boolean=false, enable:boolean=false, isSendScore:boolean=true, isUpdate:boolean=true, backCall:Function=null, scope:any=null):void{
        if(index == -2) index = getBranchIndexByScore();
        var arr = [VideoType.END+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
        if(isSendScore) setTimeout(sendScoreEvent, 1000, answerScore, getRobotScore(), isUpdate);
    }
    /** 通知APP播放纠错视频，播放时会屏蔽界面操作。
     * index 要播放当前小节的纠错视频缩影(1:为失败情况，2:为完成的情况)。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频，默认为false。
     * enable 播放中，是否可以执行界面操作。
     * isSendScore 是否向服务器发送得分，默认为true。
     * isUpdate 是否更新得分显示，如果不更新，则由老师发放分数时更新。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playCorrect(index:number, isWait:boolean=false, enable:boolean=false, isSendScore:boolean=true, isUpdate:boolean=true, backCall:Function=null, scope:any=null):void{
        var arr = [VideoType.CORRECT+"&"+index];
        sendVideoEvent(arr, isWait, enable, backCall, scope);
        if(index == 1){
            if(isSendScore) setTimeout(sendScoreEvent, 1000, "0", getRobotScore(), isUpdate);
        }else{
            if(isSendScore) setTimeout(sendScoreEvent, 1000, answerScore, getRobotScore(), isUpdate);
        }
    }
    /** 通知APP播放对战小节的结果，两个节点的分支组合播放，播放时会屏蔽界面操作。
     * ptIndex 对战结果提示缩影。缩影从1开始。
     * plIndex 对战结果提示缩影。缩影从1开始。
     * pwIndex 对战结果提示缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频，默认为false。
     * enable 播放作答正确中，是否可以执行界面操作。
     * isSendScore 是否向服务器发送得分，默认为true。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playPVP(ptIndex:number, plIndex:number=-1, pwIndex:number=-1, isWait:boolean=false, enable:boolean=false, backCall:Function=null, scope:any=null):void{
        var arr = [VideoType.PT+"&"+ptIndex];
        if(plIndex != -1) arr.push(VideoType.PL+"&"+plIndex);
        if(pwIndex != -1) arr.push(VideoType.PW+"&"+pwIndex);
        sendVideoEvent(arr, isWait, enable, backCall, scope);
    }



    /** 通知APP播放一组提示视频。
     * arr 提示节点下的一组缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放提示中，是否可以执行界面操作。
     * isReduceAnswerScore 是否减少作答得分，默认为false。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playTipArr(arr:Array<number>, isWait:boolean=true, enable:boolean=false, isReduceAnswerScore:boolean=false, backCall:Function=null, scope:any=null):void{
        if(isReduceAnswerScore) reduceAnswerScore();
        var a = [];
        for(var i=0; i<arr.length; i++){
            a.push(VideoType.TIP+"&"+arr[i]);
        }
        sendVideoEvent(a, isWait, enable, backCall, scope);
    }
    /** 通知APP播放一组乱作答视频，播放作答错误视频时会屏蔽界面操作，每作答错误一次扣一分。
     * arr 乱作答节点下的一组缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放乱作答中，是否可以执行界面操作。
     * isReduceAnswerScore 是否减少作答得分，默认为true。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。 */
    static playSlovenlyArr(arr:Array<number>, isWait:boolean=true, enable:boolean=false, isReduceAnswerScore:boolean=true, backCall:Function=null, scope:any=null):void{
        if(isReduceAnswerScore) reduceAnswerScore();
        var a = [];
        for(var i=0; i<arr.length; i++){
            a.push(VideoType.SLOVENLY+"&"+arr[i]);
        }
        sendVideoEvent(a, isWait, enable, backCall, scope);
        answerWrongNum++;
    }
    /** 通知APP播放一组点偏了视频，播放视频时会屏蔽界面操作。
     * arr 正确节点下的一组缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放中，是否可以执行界面操作。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playDeviateArr(arr:Array<number>, isWait:boolean=true, enable:boolean=false, backCall:Function=null, scope:any=null):void{
        var a = [];
        for(var i=0; i<arr.length; i++){
            a.push(VideoType.DEVIATE+"&"+arr[i])
        }
        sendVideoEvent(a, isWait, enable, backCall, scope);
    }
    /** 通知APP播放一组作答错误视频，播放作答错误视频时会屏蔽界面操作，每作答错误一次扣一分。
     * arr 错误节点下的一组缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放作答错误中，是否可以执行界面操作。
     * isReduceAnswerScore 是否减少作答得分，默认为true。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。 */
    static playWrongArr(arr:Array<number>, isWait:boolean=true, enable:boolean=false, isReduceAnswerScore:boolean=true, backCall:Function=null, scope:any=null):void{
        if(isReduceAnswerScore) reduceAnswerScore();
        var a = [];
        for(var i=0; i<arr.length; i++){
            a.push(VideoType.WRONG+"&"+arr[i]);
        }
        sendVideoEvent(a, isWait, enable, backCall, scope);
        answerWrongNum++;
    }
    /** 通知APP播放一组作答正确视频，播放作答正确视频时会屏蔽界面操作。
     * arr 正确节点下的一组缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放作答正确中，是否可以执行界面操作。
     * isSendScore 是否向服务器发送得分，默认为true。
     * isUpdate 是否更新得分显示，如果不更新，则由老师发放分数时更新。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playRightArr(arr:Array<number>, isWait:boolean=false, enable:boolean=false, isSendScore:boolean=true, isUpdate:boolean=true, backCall:Function=null, scope:any=null):void{
        var a = [];
        for(var i=0; i<arr.length; i++){
            a.push(VideoType.RIGHT+"&"+arr[i]);
        }
        sendVideoEvent(a, isWait, enable, backCall, scope);
        if(isSendScore) setTimeout(sendScoreEvent, 1000, answerScore, getRobotScore(), isUpdate);
    }
    /** 通知APP播放一组作答结束视频，播放视频时会屏蔽界面操作。
     * arr 正确节点下的一组缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放中，是否可以执行界面操作。
     * isSendScore 是否向服务器发送得分，默认为true。
     * isUpdate 是否更新得分显示，如果不更新，则由老师发放分数时更新。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playEndArr(arr:Array<number>, isWait:boolean=true, enable:boolean=false, isSendScore:boolean=true, isUpdate:boolean=true, backCall:Function=null, scope:any=null):void{
        var a = [];
        for(var i=0; i<arr.length; i++){
            a.push(VideoType.END+"&"+arr[i])
        }
        sendVideoEvent(a, isWait, enable, backCall, scope);
        if(isSendScore) setTimeout(sendScoreEvent, 1000, answerScore, getRobotScore(), isUpdate);
    }
    /** 通知APP播放一组纠错视频，播放视频时会屏蔽界面操作。
     * arr 正确节点下的一组缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放中，是否可以执行界面操作。
     * isSendScore 是否向服务器发送得分，默认为true。
     * isUpdate 是否更新得分显示，如果不更新，则由老师发放分数时更新。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playCorrectArr(arr:Array<number>, isWait:boolean=true, enable:boolean=false, isSendScore:boolean=true, isUpdate:boolean=true, backCall:Function=null, scope:any=null):void{
        var a = [];
        for(var i=0; i<arr.length; i++){
            a.push(VideoType.CORRECT+"&"+arr[i])
        }
        sendVideoEvent(a, isWait, enable, backCall, scope);
        if(isSendScore) setTimeout(sendScoreEvent, 1000, answerScore, getRobotScore(), isUpdate);
    }


    /** 通知APP播放一组视频(可以是不同节点下的视频组合，但不能跨小节，通用视频可以)，播放视频时会屏蔽界面操作。
     * arr 正确节点下的一组缩影。缩影从1开始。
     * isWait 播放完成时，是否进入待机视频。
     * enable 播放作答正确中，是否可以执行界面操作。
     * isReduceAnswerScore 是否减少作答得分，默认为false。
     * isSendScore 是否向服务器发送得分，默认为false。
     * isUpdate 如果设置了分数，是否更新显示。如果不立刻更新，则在时间点事件中来更新。
     * backCall 提示视频播放完后的回调函数。
     * scope 回调范围。*/
    static playArr(arr:Array<string>, isWait:boolean=false, enable:boolean=false, isReduceAnswerScore:boolean=false, isSendScore:boolean=false, isUpdate:boolean=true, backCall:Function=null, scope:any=null):void{
        if(isReduceAnswerScore) reduceAnswerScore();
        sendVideoEvent(arr, isWait, enable, backCall, scope);
        if(isSendScore) setTimeout(sendScoreEvent, 1000, answerScore, getRobotScore(), isUpdate);
    }
}