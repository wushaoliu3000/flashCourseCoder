/** 通过此变量，可以访问所有加载模块库中的资源 */
declare var AdobeAn:any;
/** 绘画的舞台 */
declare var stage:createjs.Stage;
/** 根视图，所有的动画与场景都在这个视图中 */
declare var exportRoot:any;
/** 网页链接传来的所有参数 */
declare var urlParams:any;

/** 设计时画布的宽度 */
declare var DW:number;
/** 设计时画布的高度 */
declare var DH:number;
/** 浏览器窗口的宽度 */
declare var SW:number;
/** 浏览器窗口的高度 */
declare var SH:number;
/** 程序内存中绘图的宽度 */
declare var CW:number;
/** 程序内存中绘图的高度 */
declare var CH:number;
/** 设计画面的大小与浏览器窗口大小的比率 */
declare var R:number;

/** 课程的配置文件（此变量在config.js文件被加载后自动付值），存储老师信息、小节目录、机器人信息…… */
declare var courseConfig;
/** 课程每个小节的配置文件（此变量在course.js文件被加载后自动付值），整个课程的小节、节点、分支都在此配置里。 */
declare var chapterConfig;
/** 视频播放控制类实例，控制课程主流程的播放、分支跳等等。 */
declare var vp:VideoPlayer;

/** 加载一页PPT或一个弹出视图。 
 * ppt 要加载的ppt页。 ppt只能在当前目录（current目录）下。
 * isPopView 是否是弹出视图。*/
declare function loadPpt(ppt:string, isPopView:any):void;

/** 播放一个库中的声音。    
  id 库中定义的声音名称。  
  loop 是否循环播放声音。*/
declare function playSound(id:string, loop?:boolean):void;

/** 输出一个调试信息。 */
declare function trace(msg:any):void;
/** 调试模式下，弹出一个提示信息。
  msg 要提示的字符串。*/
declare function popupDebug(msg:string):void;
/** 在手机上显示调试控制台。 */
declare function showConsole(); 
/** 在手机上隐藏调试控制台。 */
declare function hideConsole(); 
/** 显示trace面板 */
declare function showTrace():void;
/** 隐藏trace面板 */
declare function hideTrace():void;

/** 设置一个实例的可点击性。
 * obj 实例对象。
 * b 可点为true，否则为flase。*/
declare function touchEnabled(obj:any, b:boolean);

/** 设置根视图的可点击性。当根视图可点击时显示计时时钟。
 * b true为可点，false为不可点*/
declare function touchRootEnabled(b:boolean);
/** 当前根视图是否可点 */
declare function rootEnabled():boolean;

/** 设置当收到父级容器传来的信息时的回调函数及范围。 父级回调函数在场景实例中设置，此变量在场景实例中设置。
  ballcall 当收到父级容器传来的信息时，调用此回调方法来把信息传到场景中。此方法接收一个字符串参数。
  scope 回调函数的执行范围。*/
declare function setParentMsgBackcall(backcall:Function, scope:any):void;
/** 清理接收父级信息的回调方法的引用。 */
declare function clearParentBackcall():void;
/** 发送一个字符串到父级容器。
  msg 要发送的字符串内容。*/
declare function sendMsgToParent(msg:string):void;
/** 发送一个播放视频事件到父级容器，通知父级播放指定的视频片段。
  type 要播放的视频类型。
  index 要播放的视频缩影(从1开始，App中有减1)，默认值：-1，表示随机播放该类型的片段。
  isWait 视频播放完成后，是否进入待机(是否允许试错)，如果不进入待机，则播放下一小节。 如果是播放提示，一定进入待机视频。
  enable 播放视频时，当前视图是否可操作。
  backcall 视频播放完成后，由app回调的函数，默认值："null"。
  scope 回调函数的执行范围。
    1、如果播放的是讲解小节的讲解片段，则播放完成后自动播放下一小节。
	2、如果播放的是问题小节的讲解片段，则播放完成后将跳到待机视频循环播放，等待学生做答。
	3、如果播放的是提示分支，则播放完成后将跳到待机视频循环播放，等待学生继续做答。
	4、如果播放的是正确分支，则播放完成后自动播放下一小节。
	5、如果播放的是错误分支，并且不允许试错，则播放完成后自动播放下一小节。
	6、如果播放的是错误分支，并且允许试错，则播放完成后将跳到待机视频循环播放，等待学生继续做答。*/
declare function sendVideoEvent(arr:Array<string>, wait:boolean, enable:boolean, backcall:Function, scope:any):void;
/** 向App设置当前做题的得分。如果只想设置一个人的得分，可以让另一个人的得分为0。
 * myScore 我的得分。
 * otherScore 陪我一起上课人的得分。
 * isUpdate 是否更新得分广本框。 true为更新，false为不更新，默认为更新。*/
declare function sendScoreEvent(myScore:number, otherScore:number, isUpdate:boolean):void;

/** 在具体类实例中注册的一个回调方法，用于执行视频播放开始时的回调。
 * 进入待机视频时，不会回调此函数。*/
declare function setVideoStartBackcall(backcall:Function, scope:any):void;
/** 清理用于执行视频播放开始时的回调。 */
declare function clearVideoStartBackcall():void;

/** 当前视频是否处于播放中（老师是否在说话中），用于判断是否应该让App播放下一段视频，因为App只要收到播放指令，就会立刻跳转。 */
declare var isPlay;

/** 当前视频是否处于待机状态(如果为false说明视频在播放)，在视频播放完成的回调函数中设置。 */
declare var isWait:boolean;
/** 第一次催促作答时间（后两次是固定的5秒），指定一个时间来等待学生作答，如果时间到，还不作答，提示催促作答。 -1表示无需提示。*/
declare var urgeAnswerTime:Number;
/** 启动延时催促做答，催促三次后，还没做答，就播放结束游戏视频，播放完后退出课程。*/
declare function startUrge():void;
/** 清除延时催促做答，清除后需要重新调用startUrge才能又启动。 */
declare function stopUrge():void;

/** 做答错误次数，每一次设置最高作答得分时，都会清零。 */
declare var answerWrongNum:number;
/** 最高作答分数。一个问题小节的最高分数，可以根据题目的不同难度设置不同的分数。 */
declare var maxAnswerScore:number;
/** 作答得分。 做本题的最终得分，初始化时为最高作答分数，每催促作答一次扣1分，每答错一次扣1分，乱作答一次扣一分，当得分为1时不再往下扣分。 */
declare var answerScore:number;
/** 设置最高作答分数。一个问题小节的最高分数，可以根据题目的不同难度设置不同的分数。每催促作答一次扣1分，每答错一次扣1分，当得分为1时不再往下扣分。 */
declare function setAnswerScore(n:number):void;
/** 减少做答得分，不会少于一分。 */
declare function reduceAnswerScore():void;
/** 获取本题得分对应的分支缩影，此分支缩影并没有指明是在那个节点下，所以所有节点都可以用 */
declare function getBranchIndexByScore():number;

/** 当前学生的名字 */
declare var myName:string;
/** 机器人的名字 */
declare var robotName:string;
/** 机器人的缩影 */
declare var robotIndex:string;
/** 机器人的级别，分：初级、中级、高级 */
declare var robotLevel:number;
/** 由App调用，设置机器人的信息 */
declare function setRoleInfo(str:string):void;
/** 获取机器人的随机得分 */
declare function getRobotScore():number;


/** 定义所有的事件类型 */
declare module EventType{
    /** 系统事件 */
    const TICK:string;

     /** 显示对象事件 */
     const ADDED:string;
     /** 显示对象事件 */
     const REMOVED:string;

    /** 显示对象的鼠标事件 */
    const CLICK:string;
    /** 显示对象的鼠标事件 */
    const MOUSE_DOWN:string;
    /** 显示对象的鼠标事件 */
    const MOUSE_OUT:string;
    /** 显示对象的鼠标事件 */
    const MOUSE_OVER:string;
     /** 显示对象的鼠标事件 */
     const PRESS_MOVE:string;
     /** 显示对象的鼠标事件 */
     const PRESS_UP:string;
    /** 显示对象的鼠标事件 */
    const ROLL_OUT:string;
    /** 显示对象的鼠标事件 */
    const ROLL_OVER:string;

    /** 舞台事件 */
    const DRAWSTART:string;
    /** 舞台事件 */
    const DRAWEND:string;
    /** 舞台事件 */
    const MOUSE_ENTER:string;
    /** 舞台事件 */
    const MOUSE_LEAVE:string;
    /** 舞台事件 */
    const STAGE_MOUSE_DOWN:string;
    /** 舞台事件 */
    const STAGE_MOUSE_MOVE:string;
    /** 舞台事件 */
    const STAGE_MOUSE_UP:string;
    /** 舞台事件 */
    const TICK_END:string;
    /** 舞台事件 */
    const TICK_START:string;
}

/** 要播放的视频类型。一节课的视频类型这样细分：小节--->节点--->分支--->分支上的时间点事件。 */
declare module VideoType{
  	/** 讲解节点，播放一个小节（讲解小节或问题小节）的讲解节点*/
	const EXPLAIN:string;
	/** 催促作答节点， 延时播放催促做答，催促三次后，还没做答，就播放结束游戏视频，播放完后退出课程。 */
	const URGE:string;
	/** 乱点节点， 当学生在答题区以外点击时，提示学生 (请认真作答)。 */
	const SLOVENLY;
	/** 提示节点， 当一个题目存在多步操作时，分步提示。如果有多个分支，并且没有指明要播放哪个，则随机播放一个。 */
	const TIP:string;
	/** 提示节点， 当一个题目存在多步操作时，并且答案区分对错，这是选对了的提示。 */
	const TIP_RIGHT:string;
	/** 提示节点， 当一个题目存在多步操作时，并且答案区分对错，这是选错了的提示。 */
	const TIP_WRONG:string;
	/** 作答正确节点，如果此节点下有多个分支，并且没有指明要播放哪个，则随机播放一个。
	 * 播放完成后，自动进入下一小节。 */
	const RIGHT:string;
	/** 作答错误节点，如果此节点下有多个分支，并且没有指明要播放哪个，则随机播放一个。 
	 * 1、如果不可以试错，则播放完成后，自动播放下一节。
	 * 2、如果可以试错，则进入待机，继续做答。
	 * 3、如果做答错误3次，则播放正确节点，播放完成后，自动播放下一节。 */
	const WRONG:string;
	/** 纠错节点，答错相应的次数之后，跳到纠错节点。播放完纠错节点，进入下一小节。 */
	const CORRECT:string;
	/** 当学生在答题区以内点击，但没有点在选项上时，提示学生（点偏了） */
	const DEVIATE:string;
	/** 答题结束，此题没有错误选项，只要做完就是对的。 */
	const END:string;
	/** 对战提示，对战小节的几个节点中的分支并成一组播放，PPT可以共用同一页 */
	const PVP:string;
	/** 对战提示，此提示会与输(PL)或赢(PW)一起连播 */
	const PT:string;
	/** 对战输 */
	const PL:string;
	/** 对战赢 */
	const PW:string;
	
	/** 随机播放一个送小红花提示 */
	const FLOWER_RANDOM:string;
	/** 通用提示(送小红花)，你太厉害了，老师送你一朵小红花。 */
	const FLOWER_1:string;
	/** 通用提示(送小红花)，哇，你真牛，老师送你一朵小红花。 */
	const FLOWER_2:string;
	/** 通用提示(送小红花)，我为你骄傲，老师送你一朵小红花。 */
	const FLOWER_3:string;
	/** 通用提示(送小红花)，你真是天才，老师送你一朵小红花。 */
	const FLOWER_4:string;
	/** 通用提示(送小红花)，你做的又快又好，老师送你一朵小红花。 */
	const FLOWER_5:string;
	
	/** 随机播放一个点赞提示 */
	const PRAISE_RANDOM:string;
	/** 通用提示(点赞)，你很积极，老师给你点个赞。 */
	const PRAISE_1:string;
	/** 通用提示(点赞)，你做的很好，老师给你点个赞。 */
	const PRAISE_2:string;
	/** 通用提示(点赞)，你很有毅力，老师给你点个赞。 */
	const PRAISE_3:string;
	/** 通用提示(点赞)，你完成的好极了，老师给你点个赞。 */
	const PRAISE_4:string;
	/** 通用提示(点赞)，你的学习态度很好，老师给你点个赞。 */
	const PRAISE_5:string;

	/** 通用提示，随机播放一个奖励你星星提示 */
	const STAR_RANDOM:string;
	/** 通用提示(奖励星星)，你做得又快又好，老师奖励你一颗星星。 */
	const STAR_1:string;
	/** 通用提示(奖励星星)，你是棒棒的，老师奖励你一颗星星。 */
	const STAR_2:string;
	/** 通用提示(奖励星星)，你做得太好了，老师奖励你一颗星星。 */
	const STAR_3:string;
	/** 通用提示(奖励星星)，你完成的好极了，老师送你一颗星星。 */
	const STAR_4:string;
	/** 通用提示(奖励星星)，你的学习态度很好，老师送你一颗星星。 */
	const STAR_5:string;
	
	/** 随机播放一个答对的通用提示 */
	const RIGHT_RANDOM:string;
	/** 通用提示(答对)，你真棒。 */
	const RIGHT_1:string;
	/** 通用提示(答对)，答对啦。 */
	const RIGHT_2:string;
	/** 通用提示(答对)，做的不错。 */
	const RIGHT_3:string;
	/** 通用提示(答对)，你真聪明。 */
	const RIGHT_4:string;
	/** 通用提示(答对)，真了不起。 */
	const RIGHT_5:string;
	/** 通用提示(答对)，好样的！加油！ */
	const RIGHT_6:string;
	/** 通用提示(答对)，你确实很会思考。 */
	const RIGHT_7:string;
	/** 通用提示(答对)，你完成的好极了。 */
	const RIGHT_8:string;
	/** 通用提示(答对)，做的很好！继续努力！ */
	const RIGHT_9:string;
	/** 通用提示(答对)，你的表现很出色，老师特别欣赏你。*/
	const RIGHT_10:string;
	
	/** 随机播放一个答错的通用提示 */
	const WRONG_RANDOM:string;
	/** 通用提示(答错)，没关系，再试试。 */
	const WRONG_1:string;
	/** 通用提示(答错)，别恢心，再试一次。 */
	const WRONG_2:string;
	/** 通用提示(答错)，别泄气，还有机会。 */
	const WRONG_3:string;
	/** 通用提示(答错)，不要放弃，你能行的。 */
	const WRONG_4:string;
	/** 通用提示(答错)，仔细想想，在来一次。 */
	const WRONG_5:string;
	/** 通用提示(答错)，在细心些，你可以做对。 */
	const WRONG_6:string;
	/** 通用提示(答错)，别着急，自信点。 */
	const WRONG_7:string;
	/** 通用提示(答错)，放松一点，别紧张。 */
	const WRONG_8:string;
	/** 通用提示(答错)，再试一试，老师知道你能行。 */
	const WRONG_9:string;
	/** 通用提示(答错)，不用着急，老师看好你。 */
	const WRONG_10:string;
	
	/** 通用提示，随机播放一个催促作答的通用提示 */
	const URGE_RANDOM:string;
	/** 通用提示(催促作答)，请你作答。 */
	const URGE_1:string ;
	/** 通用提示(催促作答)，大胆作答吧，错了没关系。 */
	const URGE_2:string;
	/** 通用提示(催促作答)，在不作答就时间到了。 */
	const URGE_3:string;

	/** 通用提示，随机播放一个多步操作，做完每一步时提示的通用提示 */
	const TIP_RANDOM:string;
	/** 通用提示(多步操作提示，做完每一步时)，很好。 */
	const TIP_1:StringConstructor;
	/** 通用提示(多步操作提示，做完每一步时)，对啦。 */
	const TIP_2:string;
	/** 通用提示(多步操作提示，做完每一步时)，不错。 */
	const TIP_3:string;
	/** 通用提示(多步操作提示，做完每一步时)，厉害。 */
	const TIP_4:string;
	/** 通用提示(多步操作提示，做完每一步时)，很棒。 */
	const TIP_5:string;

	/** 随机播放一个不认真做答（在作答区域外点击）的通用提示 */
	const SLOVENLY_RANDOM:string;
	/** 通用提示（不认真做答）请认真做答。  */
	const SLOVENLY_1:string;
	/** 通用提示（不认真做答）不能乱点唷。 */
	const SLOVENLY_2:string;
	/** 通用提示（不认真做答）你需要认真做答。 */
	const SLOVENLY_3:string;

	/** 通用提示(答题结束)，此题没有错误选项，只要做完就是对的。 */
	const END_RANDOM:string;
	/** 通用提示(答题结束)，你做的又快又好，老师给你点2个攒。。 */
	const END_1:string;
	/** 通用提示(答题结束)，此题没有错误选项，只要做完就是对的。 */
	const END_2:string;
	/** 通用提示(答题结束)，此题没有错误选项，只要做完就是对的。 */
	const END_3:string;

	/** 通用提示，当学生在答题区以内点击，但没有点在选项上时，提示学生（点偏了）  */
	const DEVIATE_RANDOM:string;
	/** 通用提示（点偏了）没点到，在试一次。  */
	const DEVIATE_1:string;
	/** 通用提示（点偏了）点偏了，在点一次。 */
	const DEVIATE_2:string;
	/** 通用提示（点偏了）看准了，在点一次。 */
	const DEVIATE_3:string;

	/** 通用提示(对战) 本次与你一起上课的同学是XX，希望你俩都能有个好成绩。 */
	const PVP_1:string;
	/** 通用提示(对战目前得分) 让我们来看看你与乐宝的当前得分吧！你的目前得分是XX，XX的目前得分是XX。。 */
	const PVP_2:string;
	/** 通用提示(对战总得分) 让我们一起来看看你俩本课的得分情况:你的总得分是XX，XX的总得分是XX。 */
	const PVP_3:string;
	/** 通用提示(对战提示) 第X小节和X小节你学的还好，但第X小节你落后了。 */
	const PT_1:string;
	/** 通用提示(对战提示) 第X小节你学的不好，第X小节与第X小节你学的不错。 */
	const PT_2:string;
	/** 通用提示(对战提示) 总体来说，你本课学的不错，一直保持领先。*/
	const PT_3:string;
	/** 通用提示(对战提示) 总体来说，你本课学的不太好，一直都落后。 */
	const PT_4:string;
	/** 通用提示(对战输) 你本课落后了，5颗星星送给XX，希望以后的课多加努力。 */
	const PL_1:string;
	/** 通用提示(对战输) 你本课不及格，3颗星星送给XX，明天你还需要在上一次。*/
	const PL_2:string;
	/** 通用提示(对战输) 你本课学的佷不好，3颗星星送给XX，希望你在学一次。 */
	const PL_3:string;
	/** 通用提示(对战赢) 本课你赢了，5颗星星送给你，你不能骄傲。 */
	const PW_1:string;
	/** 通用提示(对战赢) 本课你获胜，3颗星星送给你，你还需要再努力。 */
	const PW_2:string;
	/** 通用提示(对战赢) 本课你虽然赢了，但你不及格，所以没有星星奖励，希望你再上一次本课。 */
	const PW_3:string;
	
	/** 随机播放一个退出课堂的通用提示 */
	const QUIT_RANDOM:string;
	/** 通用提示(退出课堂)，小朋友，你累了吗？休息一下在学吧！ */
	const QUIT_1:string;
	/** 通用提示(退出课堂)，小朋友，你有事吗？过一会在学吧！ */
	const QUIT_2:string;
	/** 通用提示(退出课堂)，小朋友，你想休息一会吗？一会在学吧！ */
	const QUIT_3:string;
}

/** 显示或隐藏当前每秒运行的侦数，此类有两个静态方法。  FPS.show();   FPS.hide(); */
declare class FPS{
    /** 显示当前每秒运行的侦数 */
    static show():void;
    /** 隐藏当前每秒运行的侦数 */
    static hide():void;
}

/** 连接WebSocket服务器，发送字符串数据，并接收字符数据。 */
declare class Socket{
    /** 连接WebSocket服务器。
      backcall 服务器数据到达时的回调函数。此函数接收一个字符串参数。
      scope 回调函数的执行范围。
      url 要连接WebSocket服务器的地址与端口。 */
    static connect(backcall:Function, scope:any, url?:string):void;
    /** 向WebSocket服务器发送一个字符串 */
    static send(msg:string):void;
}


/** 加载一个动画场景，包括JS文件与资源文件。
  path 要加载的JS库的路径，文件名就行，不要类型后辍。
  id 动画模块的id，由flash创作工具生成。
  callback 加载完成后的回调函数。
  scope 回调函数的执行范围。 */
declare function loadModule(path:string, id:string, callback:Function, scope:any):void;

/** 清除模块加载时，传递方法与类的引用。
  id 要删除的已经加载的模块ID。*/
declare function clearLoadModule(id?:string):void;

/** 获取exportRoot下的一个对象， 并作为MovieClip返回。  
  path 相对于exportRoot对象下的路径。如：role 或 content.role 或 exportRoot.content.role */
declare function getMC(name:string):createjs.MovieClip;

/** 获取exportRoot下的一个对象， 并作为any返回。    
  path 相对于exportRoot对象下的路径。如：role 或 content.role 或 exportRoot.content.role */
declare function getAny(name:string):any;

/** 创建(new)一个库中的对象， 并作为MovieClip类型的实例返回。
 name 要获取的库中的定义。 */
declare function createMC(name:string):createjs.MovieClip;

/** 创建(new)一个库中的对象， 并作为MovieClip类型的实例返回。
 name 要获取的库中的定义。*/
declare function createAny(name:string):any;



/** 停止一个动画及所有的子动画。
  mc 要停止动画的影片剪辑。
  isDelay 是否延时执行，一个动画被新建时，如果立刻调用stopMc方法，或调用本身的stop方法，是不起作用的。所以需要延时调用。
  如果感觉延时执行不合适，可以在显示对象的added事件中执行。  */
declare function stopAllMc(mc:createjs.MovieClip, isDelay?:boolean):void;

/** 停止一个动画。如果有嵌套多级子动画，只停止第一级的动画。要想停止所有嵌套的子动画，用stopAllMc。
  mc 要停止动画的影片剪辑。
  isDelay 是否延时执行，一个动画被新建时，如果立刻调用stopMc方法，或调用本身的stop方法，是不起作用的。所以需要延时调用。
  如果感觉延时执行不合适，可以在显示对象的added事件中执行。  */
declare function stopMc(mc:createjs.MovieClip, isDelay?:boolean):void;

/** 播放一个动画。如果有嵌套多级子动画，只播放第一级的动画。*/
declare function playMc(mc:createjs.MovieClip):void;

/** 判断指定的MC中是否存在指定的标签，存在返回true，否则返回false。 */
declare function hasLabel(mc:createjs.MovieClip, label:string):boolean;
/** 让指定的MC跳到指定的标签处并停止，如果mc或标签不存在，则不执行任何操作。 */
declare function gotoLabelAndStop(mc:createjs.MovieClip, label:string):void;
/** 让指定的MC跳到指定的标签处并播放，如果mc或标签不存在，则不执行任何操作。 */
declare function gotoLabelAndPlay(mc:createjs.MovieClip, label:string):void;

/** 判断一个点，是否跟一个对象碰撞，假如hitObj存在，则用hitObj的位置与宽高来判断。
 * item 要碰撞的对象。
 * sx 本地X坐标（e.localX）。
 * sy 本地y坐标（e.localY）。*/
declare function hitTest(item:createjs.MovieClip, sx:number, sy:number):boolean;
/** 判断两个对象是否相碰，通过全局坐标来判断，假如hitObj存在，则用hitObj的位置与宽高来判断 */
declare function hitTestObj(item0:createjs.MovieClip, item1:createjs.MovieClip):boolean;